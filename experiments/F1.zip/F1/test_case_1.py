class TextFormatter:
    def __init__(self, line_width):
        self.line_width = line_width

    def center_text(self, word):
        padding = (self.line_width - len(word)) // 2
        centered_word = " " * padding + word + " " * padding
        return centered_word




import unittest


class TestTextFormatter(unittest.TestCase):
    def test_word_centering(self):
        formatter = TextFormatter(10)
        self.assertEqual(formatter.center_text("word"), "   word   ")

if __name__ == "__main__":
    unittest.main()