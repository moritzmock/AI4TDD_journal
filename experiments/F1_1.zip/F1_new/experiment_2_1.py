class TextFormatter:
    def setLineWidth(self, width):
        self.lineWidth = width

    def center(self, text):
        padding = (self.lineWidth - len(text)) // 2
        right_padding = self.lineWidth - len(text) - padding
        padded_text = " " * padding + text + " " * right_padding
        return padded_text




import unittest


class TestTextFormatter(unittest.TestCase):

    def test_center_single_word(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        result = formatter.center("word")
        self.assertEqual(result, "   word   ")

    def test_center_single_word_hello(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        result = formatter.center("hello")
        self.assertEqual(result, "  hello   ")


if __name__ == '__main__':
    unittest.main()