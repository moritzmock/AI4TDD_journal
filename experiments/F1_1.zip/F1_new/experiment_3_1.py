class TextFormatter:
    def setLineWidth(self, width):
        self.lineWidth = width

    def center(self, text):
        padding = (self.lineWidth - len(text)) // 2
        right_padding = self.lineWidth - len(text) - padding
        padded_text = " " * padding + text + " " * right_padding
        return padded_text
    
    def center_two_words(self, words):
        word1 = self.center(words[0])
        word2 = self.center(words[1])
        return word1 + " " + word2





import unittest


class TestTextFormatter(unittest.TestCase):

    def test_center_single_word(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        result = formatter.center("word")
        self.assertEqual(result, "   word   ")

    def test_center_single_word_hello(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        result = formatter.center("hello")
        self.assertEqual(result, "  hello   ")

    def test_center_two_words(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        result = formatter.center_two_words(["foo", "bar"])
        self.assertEqual(result, " foo bar  ")

if __name__ == '__main__':
    unittest.main()