import unittest


class TestTextFormatter(unittest.TestCase):

    def test_center_single_word(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        result = formatter.center("word")
        self.assertEqual(result, "   word   ")

if __name__ == '__main__':
    unittest.main()