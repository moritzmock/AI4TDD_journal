class TextFormatter:
    def setLineWidth(self, line_width):
        self.line_width = line_width

    def centerWord(self, word):
        pad_length = (self.line_width - len(word)) // 2
        if (self.line_width - len(word)) % 2 != 0:
            pad_length_left = pad_length
            pad_length_right = pad_length + 1
        else:
            pad_length_left = pad_length_right = pad_length
        
        centered_word = ' ' * pad_length_left + word + ' ' * pad_length_right
        return centered_word
    
    def centerWords(self, words):
        total_words_length = sum(map(len, words))
        total_space = self.line_width - total_words_length
        num_spaces = len(words) - 1
        
        space_between = total_space // num_spaces
        extra_space = total_space % num_spaces
        
        centered_words = words[0]
        for i in range(1, len(words)):
            centered_words += ' ' * space_between
            if i <= extra_space:
                centered_words += ' '
            centered_words += words[i]
        
        return centered_words




import unittest


class TestTextFormatter(unittest.TestCase):
    def test_centerWords_twoWords(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_words = formatter.centerWords(['foo', 'bar'])
        self.assertEqual(centered_words, ' foo bar  ')
        
    # Existing tests
    def test_centerWord(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_word = formatter.centerWord('word')
        self.assertEqual(centered_word, '   word   ')

    # Barely minimal test for new feature
    def test_centerWord_hello(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_word = formatter.centerWord('hello')
        self.assertEqual(centered_word, '  hello   ')


if __name__ == '__main__':
    unittest.main()