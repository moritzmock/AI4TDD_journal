class TextFormatter:
    def setLineWidth(self, line_width):
        self.line_width = line_width

    def centerWords(self, words):
        total_words_length = sum(len(word) for word in words)
        total_spaces = self.line_width - total_words_length
        num_words = len(words)
        avg_spaces_between_words = total_spaces // (num_words - 1) if num_words > 1 else 0
        extra_spaces = total_spaces % (num_words - 1)

        centered_words = ''
        for i, word in enumerate(words):
            centered_words += word
            if i < num_words - 1:
                centered_words += ' ' * avg_spaces_between_words
                if extra_spaces > 0:
                    centered_words += ' '
                    extra_spaces -= 1

        return centered_words + ' ' * (self.line_width - len(centered_words))





import unittest


class TestTextFormatter(unittest.TestCase):
    def test_centerWords_twoWords(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_words = formatter.centerWords(['foo', 'bar'])
        self.assertEqual(centered_words, ' foo bar  ')
        
    # Existing tests
    def test_centerWord(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_word = formatter.centerWord('word')
        self.assertEqual(centered_word, '   word   ')

    # Barely minimal test for new feature
    def test_centerWord_hello(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_word = formatter.centerWord('hello')
        self.assertEqual(centered_word, '  hello   ')


if __name__ == '__main__':
    unittest.main()