class TextFormatter:
    def setLineWidth(self, line_width):
        self.line_width = line_width

    def centerWords(self, words):
        total_words_length = sum(len(word) for word in words)
        total_spaces = self.line_width - total_words_length
        num_words = len(words)

        avg_spaces = total_spaces // (num_words - 1) if num_words > 1 else total_spaces
        extra_spaces = total_spaces % (num_words - 1) if num_words > 1 else 0

        centered_words = words[0]
        for i in range(1, num_words):
            spaces = avg_spaces
            if extra_spaces > 0:
                extra_spaces -= 1
                spaces += 1
            centered_words += ' ' * spaces + words[i]

        return centered_words





import unittest


class TestTextFormatter(unittest.TestCase):
    def test_centerWords_twoWords(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_words = formatter.centerWords(['foo', 'bar'])
        self.assertEqual(centered_words, ' foo bar  ')
        
    # Existing tests
    def test_centerWord(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_word = formatter.centerWord('word')
        self.assertEqual(centered_word, '   word   ')

    # Barely minimal test for new feature
    def test_centerWord_hello(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_word = formatter.centerWord('hello')
        self.assertEqual(centered_word, '  hello   ')


if __name__ == '__main__':
    unittest.main()