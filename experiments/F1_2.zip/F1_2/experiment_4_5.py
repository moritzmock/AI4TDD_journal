class TextFormatter:
    def setLineWidth(self, line_width):
        self.line_width = line_width

    def centerWords(self, words):
        total_words_length = sum(len(word) for word in words)
        total_spaces_needed = self.line_width - total_words_length
        average_spaces = total_spaces_needed // (len(words) - 1) if len(words) > 1 else total_spaces_needed

        centered_words = words[0]
        for word in words[1:]:
            centered_words += ' ' * average_spaces + word

        remaining_spaces = total_spaces_needed - average_spaces * (len(words) - 1)
        centered_words += ' ' * remaining_spaces

        return centered_words





import unittest


class TestTextFormatter(unittest.TestCase):
    def test_centerWords_twoWords(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_words = formatter.centerWords(['foo', 'bar'])
        self.assertEqual(centered_words, ' foo bar  ')
        
    # Existing tests
    def test_centerWord(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_word = formatter.centerWord('word')
        self.assertEqual(centered_word, '   word   ')

    # Barely minimal test for new feature
    def test_centerWord_hello(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_word = formatter.centerWord('hello')
        self.assertEqual(centered_word, '  hello   ')


if __name__ == '__main__':
    unittest.main()