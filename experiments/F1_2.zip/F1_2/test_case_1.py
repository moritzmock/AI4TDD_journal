import unittest


class TestTextFormatter(unittest.TestCase):
    def test_centerWord(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_word = formatter.centerWord('word')
        self.assertEqual(centered_word, '  word    ')

if __name__ == '__main__':
    unittest.main()