class TextFormatter:
    def setLineWidth(self, line_width):
        self.line_width = line_width

    def centerWord(self, word):
        pad_length = (self.line_width - len(word)) // 2
        centered_word = ' ' * pad_length + word + ' ' * pad_length
        return centered_word

import unittest


class TestTextFormatter(unittest.TestCase):
    def test_centerWord(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_word = formatter.centerWord('word')
        self.assertEqual(centered_word, '   word   ')

    # Barely minimal test for new feature
    def test_centerWord_hello(self):
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        centered_word = formatter.centerWord('hello')
        self.assertEqual(centered_word, '  hello   ')


if __name__ == '__main__':
    unittest.main()