class TextFormatter:

    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def centerWord(self, word):
        padding_width = (self.lineWidth - len(word)) // 2
        padding = ' ' * padding_width
        if (self.lineWidth - len(word)) % 2 == 0:
            centered_word = padding + word + padding
        else:
            centered_word = padding + word + padding + ' '
        return centered_word

    def centerTwoWords(self, word_1, word_2):
        words = [word_1, word_2]
        combined_word = ' '.join(words)
        padding_width = (self.lineWidth - len(combined_word)) // 2
        if (self.lineWidth - len(combined_word)) % 2 == 0:
            padding = ' ' * padding_width
            centered_words = padding + combined_word + padding
        else:
            padding = ' ' * padding_width
            centered_words = padding + combined_word + padding + ' '
        return centered_words




import unittest


class TestTextFormatter(unittest.TestCase):
    
    def test_centerWord(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerWord('word'), '   word   ')

    def test_centerWord_hello(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerWord('hello'), '  hello   ')
    
    def test_centerTwoWords(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerTwoWords(['foo', 'bar']), ' foo bar  ')

if __name__ == '__main__':
    unittest.main()