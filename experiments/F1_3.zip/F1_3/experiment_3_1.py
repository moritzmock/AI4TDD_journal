class TextFormatter:

    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def centerWord(self, word):
        padding_width = (self.lineWidth - len(word)) // 2
        padding = ' ' * padding_width
        if (self.lineWidth - len(word)) % 2 == 0:
            centered_word = padding + word + padding
        else:
            centered_word = padding + word + padding + ' '
        return centered_word
        
    def centerTwoWords(self, words):
        total_length = sum(len(word) for word in words) + len(words) - 1
        spaces_to_add = self.lineWidth - total_length
        each_space = spaces_to_add // (len(words) - 1)
        extra_spaces = spaces_to_add % (len(words) - 1)
        result = words[0]
        for i in range(1, len(words)):
            result += ' ' * each_space
            if extra_spaces > 0:
                result += ' '
                extra_spaces -= 1
            result += words[i]
        return result




import unittest


class TestTextFormatter(unittest.TestCase):
    
    def test_centerWord(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerWord('word'), '   word   ')

    def test_centerWord_hello(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerWord('hello'), '  hello   ')
    
    def test_centerTwoWords(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerTwoWords(['foo', 'bar']), ' foo bar  ')

if __name__ == '__main__':
    unittest.main()