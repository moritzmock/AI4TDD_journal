class TextFormatter:

    # Existing methods are here

    def centerTwoWords(self, words):
        if len(words) != 2:
            return None
        
        padding_space = ' ' * ((self.lineWidth - len(words[0]) - len(words[1])) // 2)

        if (self.lineWidth - len(words[0]) - len(words[1])) % 2 == 0:
            centered_words = padding_space + words[0] + ' ' + words[1] + padding_space
        else:
            centered_words = padding_space + words[0] + ' ' + words[1] + padding_space + ' '
        
        return centered_words




import unittest


class TestTextFormatter(unittest.TestCase):
    
    def test_centerWord(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerWord('word'), '   word   ')

    def test_centerWord_hello(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerWord('hello'), '  hello   ')
    
    def test_centerTwoWords(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerTwoWords(['foo', 'bar']), ' foo bar  ')

if __name__ == '__main__':
    unittest.main()