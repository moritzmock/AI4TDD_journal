class TextFormatter:

    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def centerWord(self, word):
        padding_width = (self.lineWidth - len(word)) // 2
        padding = ' ' * padding_width
        centered_word = padding + word + padding
        if (self.lineWidth - len(word)) % 2 != 0:
            centered_word += ' '
        return centered_word

    def centerTwoWords(self, words):
        total_length = sum(len(word) for word in words) + len(words) - 1
        padding_width = (self.lineWidth - total_length) // 2
        padding = ' ' * padding_width
        centered_sentence = padding
        for i, word in enumerate(words):
            centered_sentence += word
            if i < len(words) - 1:
                centered_sentence += ' '
        centered_sentence += padding
        return centered_sentence





import unittest


class TestTextFormatter(unittest.TestCase):
    
    def test_centerWord(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerWord('word'), '   word   ')

    def test_centerWord_hello(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerWord('hello'), '  hello   ')
    
    def test_centerTwoWords(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerTwoWords(['foo', 'bar']), ' foo bar  ')

if __name__ == '__main__':
    unittest.main()