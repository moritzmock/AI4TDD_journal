class TextFormatter:

    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def centerWord(self, word):
        padding_width = (self.lineWidth - len(word)) // 2
        padding = ' ' * padding_width
        if (self.lineWidth - len(word)) % 2 == 0:
            centered_word = padding + word + padding
        else:
            centered_word = padding + word + padding + ' '
        return centered_word

    def centerTwoWords(self, words):
        total_length = sum(len(word) for word in words)
        space_length = self.lineWidth - total_length
        space_count = len(words) - 1
        each_space_count = space_length // space_count
        extra_space_count = space_length % space_count

        result = ""
        for i in range(len(words)):
            result += words[i]
            if i < len(words) - 1:
                result += " " * each_space_count
                if extra_space_count > 0:
                    result += " "
                    extra_space_count -= 1
        return result.center(self.lineWidth)






import unittest


class TestTextFormatter(unittest.TestCase):
    
    def test_centerWord(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerWord('word'), '   word   ')

    def test_centerWord_hello(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerWord('hello'), '  hello   ')
    
    def test_centerTwoWords(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerTwoWords(['foo', 'bar']), ' foo bar  ')

if __name__ == '__main__':
    unittest.main()