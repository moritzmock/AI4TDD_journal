import unittest


class TestTextFormatter(unittest.TestCase):
    
    def test_centerWord(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerWord('word'), '   word   ')
    
if __name__ == '__main__':
    unittest.main()