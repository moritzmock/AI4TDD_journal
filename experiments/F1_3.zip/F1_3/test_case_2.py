class TextFormatter:

    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def centerWord(self, word):
        padding_width = (self.lineWidth - len(word)) // 2
        padding = ' ' * padding_width
        centered_word = padding + word + padding
        return centered_word

import unittest


class TestTextFormatter(unittest.TestCase):
    
    def test_centerWord(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerWord('word'), '   word   ')

    def test_centerWord_hello(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        self.assertEqual(tf.centerWord('hello'), '  hello   ')
    
if __name__ == '__main__':
    unittest.main()