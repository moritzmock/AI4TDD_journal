TextFormatter (Python)

Overview
- TextFormatter centers text in a line of configurable width.
- API:
  - setLineWidth(width): set the line width (int >= 1)
  - center(word): center a single word
  - center_two(word1, word2): center two words with a single space between them
- Rules:
  - If the text is as long or longer than the line width, the original text is returned unchanged.
  - For odd padding, the left side uses floor and the right side uses the remainder.

Project layout
- text_formatter.py
- tests/test_text_formatter.py
- todo.md

How to run tests
Option A: With pytest (recommended)
1) Install pytest if needed: pip install pytest
2) From the project root, run:
   - pytest -q
   or
   - python -m pytest -q

Option B: Without any test framework
- Simply run:
  - python tests/test_text_formatter.py
- This uses a very small built-in runner in the test file that calls all test_* functions.

Sample usage
>>> from text_formatter import TextFormatter
>>> tf = TextFormatter()
>>> tf.setLineWidth(10)
>>> tf.center("cat")
'   cat    '
>>> tf.center_two("hello", "world")
'hello world '