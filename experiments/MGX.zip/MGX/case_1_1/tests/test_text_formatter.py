from text_formatter import TextFormatter


def test_set_line_width_invalid_raises():
    fmt = TextFormatter()
    try:
        fmt.setLineWidth(0)
        assert False, "Expected ValueError for width < 1"
    except ValueError:
        pass

    try:
        fmt.setLineWidth(-5)
        assert False, "Expected ValueError for width < 1"
    except ValueError:
        pass

    try:
        fmt.setLineWidth(3.5)  # type: ignore[arg-type]
        assert False, "Expected TypeError for non-integer width"
    except TypeError:
        pass


def test_center_before_setting_width_raises():
    fmt = TextFormatter()
    try:
        fmt.center("cat")
        assert False, "Expected ValueError when width is not set"
    except ValueError:
        pass


def test_center_even_width():
    fmt = TextFormatter()
    fmt.setLineWidth(10)
    # width 10, word len 3 => total spaces 7 => left=3, right=4
    assert fmt.center("cat") == "   cat    "


def test_center_odd_width():
    fmt = TextFormatter(9)
    # width 9, word len 3 => total spaces 6 => left=3, right=3
    assert fmt.center("cat") == "   cat   "


def test_center_word_longer_than_width_returns_word():
    fmt = TextFormatter(2)
    assert fmt.center("cat") == "cat"


def test_center_two_basic_fit_exact_with_padding():
    fmt = TextFormatter(12)
    # "hello world" length = 11 -> total spaces 1 -> left=0, right=1
    assert fmt.center_two("hello", "world") == "hello world "


def test_center_two_even_width():
    fmt = TextFormatter(13)
    # "hi there" length = 8 -> total spaces 5 -> left=2, right=3
    assert fmt.center_two("hi", "there") == "  hi there   "


def test_center_two_too_long_returns_plain():
    fmt = TextFormatter(5)
    assert fmt.center_two("hello", "world") == "hello world"


def test_type_errors_for_center_and_center_two():
    fmt = TextFormatter(10)
    try:
        fmt.center(123)  # type: ignore[arg-type]
        assert False, "Expected TypeError for non-string word"
    except TypeError:
        pass

    try:
        fmt.center_two("ok", 42)  # type: ignore[arg-type]
        assert False, "Expected TypeError for non-string word2"
    except TypeError:
        pass

    try:
        fmt.center_two(None, "ok")  # type: ignore[arg-type]
        assert False, "Expected TypeError for non-string word1"
    except TypeError:
        pass


if __name__ == "__main__":
    # Simple test runner without external frameworks
    for name, func in list(globals().items()):
        if name.startswith("test_") and callable(func):
            func()
    print("All tests passed.")