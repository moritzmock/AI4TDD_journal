from __future__ import annotations


class TextFormatter:
    """A utility that centers text within a configured line width."""

    def __init__(self, width: int | None = None) -> None:
        self._width: int | None = None
        if width is not None:
            self.setLineWidth(width)

    def setLineWidth(self, width: int) -> None:
        """Set the target line width.

        Args:
            width: Desired line width, must be an integer >= 1.

        Raises:
            TypeError: If width is not an integer.
            ValueError: If width < 1.
        """
        if not isinstance(width, int):
            raise TypeError("width must be an integer")
        if width < 1:
            raise ValueError("width must be >= 1")
        self._width = width

    def _ensure_width(self) -> None:
        if self._width is None:
            raise ValueError("Line width is not set. Call setLineWidth first.")

    def center(self, word: str) -> str:
        """Center a single word within the configured line width.

        If the word's length is greater than or equal to the line width, the
        word is returned unchanged.

        Args:
            word: The word to center.

        Returns:
            The centered string.

        Raises:
            ValueError: If line width has not been set.
            TypeError: If word is not a string.
        """
        self._ensure_width()
        if not isinstance(word, str):
            raise TypeError("word must be a string")
        assert self._width is not None  # for type checkers
        wlen = len(word)
        if wlen >= self._width:
            return word
        total_spaces = self._width - wlen
        left = total_spaces // 2
        right = total_spaces - left
        return (" " * left) + word + (" " * right)

    def center_two(self, word1: str, word2: str) -> str:
        """Center two words within the configured line width.

        The two words are joined by a single space and then centered.
        If the resulting string's length is greater than or equal to the line width,
        the unmodified 'word1 word2' is returned.

        Args:
            word1: First word.
            word2: Second word.

        Returns:
            The centered string.

        Raises:
            ValueError: If line width has not been set.
            TypeError: If either word1 or word2 is not a string.
        """
        self._ensure_width()
        if not isinstance(word1, str) or not isinstance(word2, str):
            raise TypeError("word1 and word2 must be strings")
        content = f"{word1} {word2}"
        assert self._width is not None  # for type checkers
        clen = len(content)
        if clen >= self._width:
            return content
        total_spaces = self._width - clen
        left = total_spaces // 2
        right = total_spaces - left
        return (" " * left) + content + (" " * right)