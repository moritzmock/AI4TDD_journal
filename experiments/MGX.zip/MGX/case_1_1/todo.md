MVP plan for TextFormatter (Python, TDD - assertion first)

Goal
- Implement a class TextFormatter that centers text within a fixed line width.
- API:
  - setLineWidth(width): set the target line length (>= 1)
  - center(word): center a single word in the line
  - center_two(word1, word2): center two words (with a single space between them) in the line
- Behavior assumptions:
  - If the text length is greater than or equal to the line width, return the text unchanged.
  - When padding spaces is odd, left padding uses floor and right padding uses ceil.
  - setLineWidth validates input (int and >= 1).

Files to create (4 files total)
1) tests/test_text_formatter.py
   - Assertion-first tests for all required behavior
   - Includes a simple __main__ runner so users can run tests without pytest
   - Drives the design and expectations for the implementation

2) text_formatter.py
   - Implements TextFormatter with:
     - __init__(width: int | None = None)
     - setLineWidth(width: int) -> None
     - center(word: str) -> str
     - center_two(word1: str, word2: str) -> str
   - Input validations and padding logic

3) README.md
   - Quick instructions on how to run the tests (with/without pytest)
   - Documented assumptions

4) todo.md
   - This plan

Relationships
- tests/test_text_formatter.py imports TextFormatter from text_formatter.py and verifies behavior via assertions.
- text_formatter.py provides the implementation required by the tests.

Scope chosen
- Strictly implement the stated features; no extra options or formatting styles beyond single-space separation for two-word centering.