"""
Test suite for TextFormatter using TDD-style assertions.
Run this file directly with Python to execute the assertions.
"""

from text_formatter import TextFormatter


def run_tests() -> None:
    # 1) Using the class without setting width should raise an error.
    tf = TextFormatter()
    try:
        tf.centerWord("cat")
        assert False, "Expected RuntimeError when line width is not set."
    except RuntimeError:
        pass

    # 2) Setting line width and centering a single word.
    tf.setLineWidth(10)
    assert tf.centerWord("cat") == "   cat    ", "Single word should be centered with correct padding."
    assert tf.centerWord("abcdefghij") == "abcdefghij", "Exact width should return the word unchanged."

    # 3) Word longer than width should raise ValueError.
    try:
        tf.centerWord("abcdefghijkl")  # len=12 > width=10
        assert False, "Expected ValueError when word length exceeds line width."
    except ValueError:
        pass

    # 4) Center two words with current width (10).
    # "foo bar" length is 7; left=1, right=2 => " foo bar  "
    assert tf.centerTwoWords("foo", "bar") == " foo bar  ", "Two words should be centered as a combined unit."

    # 5) Change width to 12 and center two words.
    # "foo bar" len=7; left=2, right=3 => "  foo bar   "
    tf.setLineWidth(12)
    assert tf.centerTwoWords("foo", "bar") == "  foo bar   ", "Padding should adjust with new width."

    # 6) Invalid widths should raise ValueError.
    try:
        tf.setLineWidth(0)
        assert False, "Expected ValueError for non-positive line width."
    except ValueError:
        pass

    # 7) Type validation for inputs.
    try:
        tf.centerWord(123)  # type: ignore[arg-type]
        assert False, "Expected TypeError for non-string word input."
    except TypeError:
        pass

    try:
        tf.centerTwoWords("foo", 456)  # type: ignore[arg-type]
        assert False, "Expected TypeError for non-string second word input."
    except TypeError:
        pass

    # 8) Constructor with initial width and centering two short words.
    tf2 = TextFormatter(11)
    # "a b" len=3; left=4, right=4 => "    a b    "
    assert tf2.centerTwoWords("a", "b") == "    a b    ", "Constructor-set width should work."

    # 9) Combined words longer than width should raise ValueError.
    tf3 = TextFormatter(5)
    try:
        tf3.centerTwoWords("hi", "there")  # "hi there" len=8 > 5
        assert False, "Expected ValueError when combined words exceed line width."
    except ValueError:
        pass

    print("All TextFormatter tests passed.")


if __name__ == "__main__":
    run_tests()