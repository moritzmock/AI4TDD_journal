"""
TextFormatter: Center words within a fixed-width line.

Provides:
- setLineWidth(width): Set the total length of the output line.
- centerWord(word): Return a single word centered in the line.
- centerTwoWords(word1, word2): Return two words (joined by a single space) centered in the line.

Behavioral details:
- Line width must be set before centering; otherwise a RuntimeError is raised.
- If the content length exceeds the line width, a ValueError is raised.
- Inputs must be strings; otherwise a TypeError is raised.
- Centering uses floor for left padding and places the remaining spaces on the right.
"""

from typing import Optional


class TextFormatter:
    def __init__(self, line_width: Optional[int] = None) -> None:
        self._line_width: Optional[int] = None
        if line_width is not None:
            self.setLineWidth(line_width)

    def setLineWidth(self, width: int) -> None:
        """Set the total length of the output line."""
        if not isinstance(width, int):
            raise TypeError("Line width must be an integer.")
        if width <= 0:
            raise ValueError("Line width must be a positive integer.")
        self._line_width = width

    def centerWord(self, word: str) -> str:
        """Center a single word within the set line width."""
        self._ensure_width_is_set()
        if not isinstance(word, str):
            raise TypeError("word must be a string.")

        content_len = len(word)
        if content_len > self._line_width:  # type: ignore[operator]
            raise ValueError(
                f"Word length ({content_len}) exceeds line width ({self._line_width})."
            )

        left = (self._line_width - content_len) // 2  # type: ignore[operator]
        right = self._line_width - content_len - left  # type: ignore[operator]
        return (" " * left) + word + (" " * right)

    def centerTwoWords(self, word1: str, word2: str) -> str:
        """Center two words (joined with a single space) within the set line width."""
        self._ensure_width_is_set()
        if not isinstance(word1, str) or not isinstance(word2, str):
            raise TypeError("word1 and word2 must be strings.")

        combined = f"{word1} {word2}"
        content_len = len(combined)
        if content_len > self._line_width:  # type: ignore[operator]
            raise ValueError(
                f"Combined length ({content_len}) exceeds line width ({self._line_width})."
            )

        left = (self._line_width - content_len) // 2  # type: ignore[operator]
        right = self._line_width - content_len - left  # type: ignore[operator]
        return (" " * left) + combined + (" " * right)

    def _ensure_width_is_set(self) -> None:
        if self._line_width is None:
            raise RuntimeError("Line width is not set. Call setLineWidth first.")