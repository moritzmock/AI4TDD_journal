from text_formatter import TextFormatter


def run_tests():
    # TDD: assertions first

    # setLineWidth accepts a positive integer
    tf = TextFormatter()
    try:
        tf.setLineWidth(10)
    except Exception as e:
        raise AssertionError(f"setLineWidth should accept a positive integer, got {e}")

    # center_single basic case: even total padding distributed left/right
    assert tf.center_single("hi") == "    hi    ", "Centering 'hi' in width 10 should be '    hi    '"

    # center_single with odd width and word length: symmetrical padding
    tf.setLineWidth(9)
    assert tf.center_single("cat") == "   cat   ", "Centering 'cat' in width 9 should be '   cat   '"

    # width equals word length: return word unchanged
    tf.setLineWidth(3)
    assert tf.center_single("cat") == "cat", "Width equals text length should return text as-is"

    # too long single word should raise ValueError
    tf.setLineWidth(3)
    try:
        tf.center_single("longer")
        raise AssertionError("Expected ValueError when word length exceeds line width")
    except ValueError:
        pass

    # center_two basic: combine with single space then center
    tf.setLineWidth(12)
    assert tf.center_two("hi", "yo") == "   hi yo    ", "Centering 'hi yo' in width 12 should be '   hi yo    '"

    # width equals combined length: return combined unchanged
    tf.setLineWidth(5)
    assert tf.center_two("hi", "yo") == "hi yo", "Width equals combined length should return combined text"

    # too long combined should raise ValueError
    tf.setLineWidth(4)
    try:
        tf.center_two("long", "word")
        raise AssertionError("Expected ValueError when combined length exceeds line width")
    except ValueError:
        pass

    # invalid line widths
    tf2 = TextFormatter()
    for invalid in [0, -1]:
        try:
            tf2.setLineWidth(invalid)
            raise AssertionError("Expected ValueError for non-positive width")
        except ValueError:
            pass
    try:
        tf2.setLineWidth(10.5)
        raise AssertionError("Expected TypeError for non-integer width")
    except TypeError:
        pass

    # centering before width is set should raise
    tf3 = TextFormatter()
    try:
        tf3.center_single("hi")
        raise AssertionError("Expected ValueError when line width has not been set")
    except ValueError:
        pass

    print("All tests passed.")


if __name__ == "__main__":
    run_tests()