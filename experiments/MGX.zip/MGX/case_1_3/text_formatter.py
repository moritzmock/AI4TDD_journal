"""
TextFormatter: a simple utility for horizontally centering words within a fixed-width line.

Usage:
    tf = TextFormatter()
    tf.setLineWidth(10)
    print(tf.center_single("hi"))  # => "    hi    "
    print(tf.center_two("hi", "yo"))  # => "   hi yo    "

Design notes:
- Line width must be a positive integer and must be set before centering.
- If the content length exceeds the line width, a ValueError is raised.
- For centering, leading padding is floor((width - len(text)) / 2), trailing padding is the remainder.
- The two-word centering combines the words with a single space and then centers the combined text.
"""

from typing import Optional


class TextFormatter:
    def __init__(self, line_width: Optional[int] = None) -> None:
        self._line_width: Optional[int] = None
        if line_width is not None:
            self.setLineWidth(line_width)

    def setLineWidth(self, width: int) -> None:
        """Set the total width of the line used for centering.

        Args:
            width: A positive integer representing the line width.

        Raises:
            TypeError: If width is not an integer.
            ValueError: If width is not a positive integer.
        """
        if not isinstance(width, int):
            raise TypeError("line width must be an integer")
        if width <= 0:
            raise ValueError("line width must be a positive integer")
        self._line_width = width

    def _require_width(self) -> None:
        if self._line_width is None:
            raise ValueError("line width has not been set. Call setLineWidth(width) first.")

    def _center_text(self, text: str) -> str:
        self._require_width()
        if not isinstance(text, str):
            raise TypeError("text must be a string")
        length = len(text)
        if length > self._line_width:
            raise ValueError("text length exceeds the current line width")
        total_space = self._line_width - length
        left = total_space // 2
        right = total_space - left
        return (" " * left) + text + (" " * right)

    def center_single(self, word: str) -> str:
        """Return the single word centered within the configured line width."""
        return self._center_text(word)

    def center_two(self, word1: str, word2: str) -> str:
        """Return the two words centered within the configured line width.

        The words are combined with a single space before centering.
        """
        combined = f"{word1} {word2}"
        return self._center_text(combined)