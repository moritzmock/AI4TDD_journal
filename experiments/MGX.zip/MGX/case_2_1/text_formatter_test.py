"""
TDD: Assertion-First style
- Tests are specified first, focused strictly on the given cases.
- Minimal production code is provided to satisfy these tests only.
"""

import unittest


class TestTextFormatter(unittest.TestCase):
    def test_center_single_word_word(self):
        # Given
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        # Assert-first: expected centered output for "word" with width=10
        self.assertEqual(formatter.center("word"), "   word   ")

    def test_center_single_word_hello(self):
        # Given
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        # Assert-first: expected centered output for "hello" with width=10
        self.assertEqual(formatter.center("hello"), "  hello   ")

    def test_center_two_words_foo_bar(self):
        # Given
        formatter = TextFormatter()
        formatter.setLineWidth(10)
        # Assert-first: expected centered output for "foo bar" with width=10
        self.assertEqual(formatter.center_two_words("foo", "bar"), " foo bar  ")


class TextFormatter:
    def __init__(self):
        self._line_width = 0

    def setLineWidth(self, width: int) -> None:
        """Set the total line width (non-negative)."""
        if not isinstance(width, int):
            raise TypeError("line width must be an integer")
        if width < 0:
            raise ValueError("line width must be non-negative")
        self._line_width = width

    def center(self, word: str) -> str:
        """Center a single word within the configured line width."""
        if not isinstance(word, str):
            raise TypeError("word must be a string")
        return self._center_text(word)

    def center_two_words(self, word1: str, word2: str) -> str:
        """Center two words (with a single space between them) within the configured line width."""
        if not isinstance(word1, str) or not isinstance(word2, str):
            raise TypeError("words must be strings")
        combined = f"{word1} {word2}"
        return self._center_text(combined)

    def _center_text(self, content: str) -> str:
        """Center the given content using simple left/right space padding."""
        total_padding = self._line_width - len(content)
        if total_padding <= 0:
            # For this TDD scope, we simply return the content unchanged if it doesn't fit.
            # We're only implementing what's necessary to pass the specified tests.
            return content
        left = total_padding // 2
        right = total_padding - left
        return (" " * left) + content + (" " * right)


if __name__ == "__main__":
    unittest.main()