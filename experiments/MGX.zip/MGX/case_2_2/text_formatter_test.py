import unittest


class TextFormatter:
    """Formats words centered within a configured line width."""

    def __init__(self, line_width: int = 0) -> None:
        self.line_width = line_width

    def setLineWidth(self, width: int) -> None:
        if width < 0:
            raise ValueError("line width must be non-negative")
        self.line_width = width

    def center_word(self, word: str) -> str:
        return self._center(word)

    def center_two_words(self, w1: str, w2: str) -> str:
        combined = f"{w1} {w2}"
        return self._center(combined)

    def _center(self, text: str) -> str:
        """Center the given text within the configured line width."""
        width = self.line_width
        if width <= 0:
            return text
        length = len(text)
        if length >= width:
            # If the text is longer than the line width, return it unchanged.
            # Behavior for this case is not part of the current test spec.
            return text
        total_spaces = width - length
        left = total_spaces // 2
        right = total_spaces - left
        return (" " * left) + text + (" " * right)


class TestTextFormatter(unittest.TestCase):
    def setUp(self) -> None:
        self.tf = TextFormatter()

    def test_single_word_width_10_word(self) -> None:
        # Assertion-First: specify expected outcome first
        expected = "   word   "
        # Arrange
        self.tf.setLineWidth(10)
        # Act
        actual = self.tf.center_word("word")
        # Assert
        self.assertEqual(actual, expected)

    def test_single_word_width_10_hello(self) -> None:
        # Assertion-First: specify expected outcome first
        expected = "  hello   "
        # Arrange
        self.tf.setLineWidth(10)
        # Act
        actual = self.tf.center_word("hello")
        # Assert
        self.assertEqual(actual, expected)

    def test_two_words_width_10_foo_bar(self) -> None:
        # Assertion-First: specify expected outcome first
        expected = " foo bar  "
        # Arrange
        self.tf.setLineWidth(10)
        # Act
        actual = self.tf.center_two_words("foo", "bar")
        # Assert
        self.assertEqual(actual, expected)


if __name__ == "__main__":
    unittest.main()