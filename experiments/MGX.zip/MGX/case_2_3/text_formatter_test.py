import unittest


class TestTextFormatter(unittest.TestCase):
    def setUp(self):
        # Arrange: Create formatter and set line width to 10
        self.tf = TextFormatter()
        self.tf.setLineWidth(10)

    def test_center_single_word_word(self):
        # Assert-First: Expected centered result for "word" with width 10
        expected = "   word   "
        # Act
        result = self.tf.center_word("word")
        # Assert
        self.assertEqual(result, expected)

    def test_center_single_word_hello(self):
        # Assert-First: Expected centered result for "hello" with width 10
        expected = "  hello   "
        # Act
        result = self.tf.center_word("hello")
        # Assert
        self.assertEqual(result, expected)

    def test_center_two_words_foo_bar(self):
        # Assert-First: Expected centered result for "foo bar" with width 10
        expected = " foo bar  "
        # Act
        result = self.tf.center_two_words("foo", "bar")
        # Assert
        self.assertEqual(result, expected)


class TextFormatter:
    """TextFormatter centers words within a line of a configured width."""

    def __init__(self):
        self._width = 0

    def setLineWidth(self, width: int) -> None:
        """Set the total width of the line."""
        self._width = int(width)

    def center_word(self, word: str) -> str:
        """Center a single word within the configured line width."""
        return self._center(word)

    def center_two_words(self, word1: str, word2: str) -> str:
        """Center two words separated by a single space within the configured line width."""
        return self._center(f"{word1} {word2}")

    def _center(self, text: str) -> str:
        """Helper: Center text according to the current line width."""
        if self._width <= 0:
            return text
        pad = self._width - len(text)
        if pad <= 0:
            return text
        left = pad // 2
        right = pad - left
        return (" " * left) + text + (" " * right)


if __name__ == "__main__":
    unittest.main()