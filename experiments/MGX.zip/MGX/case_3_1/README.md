# TextFormatter Class

A Python class that horizontally centers words in lines of specified width.

## Features

The `TextFormatter` class provides three main functions:

1. **`setLineWidth(width)`** - Sets the length of the line
2. **`center_single_word(word)`** - Centers a single word in the line
3. **`center_two_words(word1, word2)`** - Centers two words in the line

## Usage

```python
from text_formatter import TextFormatter

# Create formatter instance
formatter = TextFormatter()

# Set line width
formatter.setLineWidth(20)

# Center single word
result1 = formatter.center_single_word("hello")
print(f"|{result1}|")  # |       hello        |

# Center two words
result2 = formatter.center_two_words("hello", "world")
print(f"|{result2}|")  # |    hello world     |
```

## Implementation Details

- **Padding Distribution**: When the total padding is odd, the extra space is added to the right side
- **Edge Cases**: 
  - Words that exactly fit the line width return without padding
  - Words longer than the line width raise a `ValueError`
  - Attempting to format without setting line width raises a `ValueError`

## Test Driven Development

This implementation was developed using Test Driven Development (TDD):

1. **Tests First**: All test cases were written before implementation
2. **Red-Green-Refactor**: Tests were run (failing), then code was written to pass them
3. **Comprehensive Coverage**: Tests cover normal cases, edge cases, and error conditions

## Running Tests

```bash
# Run with pytest
python -m pytest test_text_formatter.py -v

# Run with unittest
python test_text_formatter.py
```

## Demo

Run the demonstration script to see the formatter in action:

```bash
python demo.py
```

## Files

- `text_formatter.py` - Main implementation
- `test_text_formatter.py` - Comprehensive test suite
- `demo.py` - Demonstration script
- `README.md` - This documentation