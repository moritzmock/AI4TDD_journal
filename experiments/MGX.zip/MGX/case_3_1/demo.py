#!/usr/bin/env python3
"""
Demonstration of the TextFormatter class functionality.
"""

from text_formatter import TextFormatter


def main():
    """Demonstrate the TextFormatter class functionality."""
    print("=== TextFormatter Demonstration ===\n")

    # Create a formatter instance
    formatter = TextFormatter()

    # Demonstrate setting line width
    print("1. Setting line width to 20")
    formatter.setLineWidth(20)
    print("Line width set successfully!\n")

    # Demonstrate single word centering
    print("2. Centering single words:")
    print("Line: " + "|" + "-" * 18 + "|")  # Visual guide

    words = ["hello", "test", "Python", "a"]
    for word in words:
        result = formatter.center_single_word(word)
        print(f"Word '{word}': |{result}|")
    print()

    # Demonstrate two words centering
    print("3. Centering two words:")
    print("Line: " + "|" + "-" * 18 + "|")  # Visual guide

    word_pairs = [
        ("hello", "world"),
        ("Python", "rocks"),
        ("hi", "there"),
        ("a", "b")
    ]

    for word1, word2 in word_pairs:
        result = formatter.center_two_words(word1, word2)
        print(f"Words '{word1}' & '{word2}': |{result}|")
    print()

    # Demonstrate different line widths
    print("4. Different line widths:")
    widths = [10, 15, 25]
    for width in widths:
        formatter.setLineWidth(width)
        result = formatter.center_single_word("center")
        print(f"Width {width:2d}: |{result}|")
    print()

    # Demonstrate edge cases
    print("5. Edge cases:")
    formatter.setLineWidth(6)
    result = formatter.center_single_word("python")  # Exact fit
    print(f"Exact fit: |{result}|")

    formatter.setLineWidth(11)
    result = formatter.center_single_word("test")  # Odd padding
    print(f"Odd padding: |{result}|")

    print("\n=== Demonstration Complete ===")


if __name__ == "__main__":
    main()