import unittest
from text_formatter import TextFormatter


class TestTextFormatter(unittest.TestCase):

    def setUp(self):
        """Set up test fixtures before each test method."""
        self.formatter = TextFormatter()

    def test_set_line_width(self):
        """Test that setLineWidth properly sets the line width."""
        self.formatter.setLineWidth(20)
        # We'll verify this works through the formatting functions

    def test_center_single_word_basic(self):
        """Test centering a single word in a line."""
        self.formatter.setLineWidth(10)
        result = self.formatter.center_single_word("test")
        expected = "   test   "  # 3 spaces on each side, total 10 chars
        assert result == expected, f"Expected '{expected}', got '{result}'"
        assert len(result) == 10, f"Expected length 10, got {len(result)}"

    def test_center_single_word_odd_padding(self):
        """Test centering a single word when padding is odd."""
        self.formatter.setLineWidth(11)
        result = self.formatter.center_single_word("test")
        # Word "test" (4 chars) in line of 11: 7 spaces to distribute
        # Should be 3 spaces left, 4 spaces right (or vice versa)
        expected = "   test    "  # 3 left, 4 right, total 11 chars
        assert result == expected, f"Expected '{expected}', got '{result}'"
        assert len(result) == 11, f"Expected length 11, got {len(result)}"

    def test_center_single_word_exact_fit(self):
        """Test centering a word that exactly fits the line."""
        self.formatter.setLineWidth(4)
        result = self.formatter.center_single_word("test")
        expected = "test"
        assert result == expected, f"Expected '{expected}', got '{result}'"
        assert len(result) == 4, f"Expected length 4, got {len(result)}"

    def test_center_two_words_basic(self):
        """Test centering two words in a line."""
        self.formatter.setLineWidth(20)
        result = self.formatter.center_two_words("hello", "world")
        # "hello world" (11 chars) in line of 20: 9 spaces to distribute
        # Should be 4 spaces left, 5 spaces right (or vice versa)
        expected = "    hello world     "  # 4 left, 5 right, total 20 chars
        assert result == expected, f"Expected '{expected}', got '{result}'"
        assert len(result) == 20, f"Expected length 20, got {len(result)}"

    def test_center_two_words_odd_padding(self):
        """Test centering two words when padding is odd."""
        self.formatter.setLineWidth(15)
        result = self.formatter.center_two_words("hi", "bye")
        # "hi bye" (6 chars) in line of 15: 9 spaces to distribute
        # Should be 4 spaces left, 5 spaces right (or vice versa)
        expected = "    hi bye     "  # 4 left, 5 right, total 15 chars
        assert result == expected, f"Expected '{expected}', got '{result}'"
        assert len(result) == 15, f"Expected length 15, got {len(result)}"

    def test_center_two_words_exact_fit(self):
        """Test centering two words that exactly fit the line."""
        self.formatter.setLineWidth(8)
        result = self.formatter.center_two_words("hi", "there")
        expected = "hi there"  # Exactly 8 characters
        assert result == expected, f"Expected '{expected}', got '{result}'"
        assert len(result) == 8, f"Expected length 8, got {len(result)}"

    def test_line_width_not_set(self):
        """Test behavior when line width is not set."""
        with self.assertRaises(ValueError):
            self.formatter.center_single_word("test")

    def test_word_too_long(self):
        """Test behavior when word is longer than line width."""
        self.formatter.setLineWidth(5)
        with self.assertRaises(ValueError):
            self.formatter.center_single_word("toolong")

    def test_two_words_too_long(self):
        """Test behavior when two words are longer than line width."""
        self.formatter.setLineWidth(5)
        with self.assertRaises(ValueError):
            self.formatter.center_two_words("hello", "world")


if __name__ == '__main__':
    unittest.main()