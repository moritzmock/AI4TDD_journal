class TextFormatter:
    """
    A class that formats text by centering words horizontally in a line of specified width.
    """

    def __init__(self):
        """Initialize the TextFormatter with no line width set."""
        self.line_width = None

    def setLineWidth(self, width):
        """
        Set the width of the line for text formatting.

        Args:
            width (int): The desired width of the line in characters.

        Raises:
            ValueError: If width is not a positive integer.
        """
        if not isinstance(width, int) or width <= 0:
            raise ValueError("Line width must be a positive integer")
        self.line_width = width

    def center_single_word(self, word):
        """
        Center a single word in the line.

        Args:
            word (str): The word to center.

        Returns:
            str: The word centered in a line of the specified width.

        Raises:
            ValueError: If line width is not set or word is too long.
        """
        if self.line_width is None:
            raise ValueError("Line width must be set before formatting text")

        if len(word) > self.line_width:
            raise ValueError(f"Word '{word}' is too long for line width {self.line_width}")

        if len(word) == self.line_width:
            return word

        # Calculate padding needed
        total_padding = self.line_width - len(word)
        left_padding = total_padding // 2
        right_padding = total_padding - left_padding

        return ' ' * left_padding + word + ' ' * right_padding

    def center_two_words(self, word1, word2):
        """
        Center two words in the line with a space between them.

        Args:
            word1 (str): The first word.
            word2 (str): The second word.

        Returns:
            str: The two words centered in a line of the specified width.

        Raises:
            ValueError: If line width is not set or words are too long.
        """
        if self.line_width is None:
            raise ValueError("Line width must be set before formatting text")

        # Combine words with a space
        combined_text = word1 + ' ' + word2

        if len(combined_text) > self.line_width:
            raise ValueError(f"Words '{word1}' and '{word2}' are too long for line width {self.line_width}")

        if len(combined_text) == self.line_width:
            return combined_text

        # Calculate padding needed
        total_padding = self.line_width - len(combined_text)
        left_padding = total_padding // 2
        right_padding = total_padding - left_padding

        return ' ' * left_padding + combined_text + ' ' * right_padding