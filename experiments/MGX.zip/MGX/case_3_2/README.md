# TextFormatter

A Python class that centers words horizontally in lines of specified width, developed using Test Driven Development (TDD).

## Features

The `TextFormatter` class provides three main functions:

1. **setLineWidth(width)**: Sets the length of the line for formatting
2. **centerSingleWord(word)**: Centers a single word in the line
3. **centerTwoWords(word1, word2)**: Centers two words in the line with a space between them

## Usage

```python
from text_formatter import TextFormatter

# Create formatter instance
formatter = TextFormatter()

# Set line width
formatter.setLineWidth(20)

# Center a single word
result1 = formatter.centerSingleWord("hello")
print(f"'{result1}'")  # Output: '       hello        '

# Center two words
result2 = formatter.centerTwoWords("hello", "world")
print(f"'{result2}'")  # Output: '    hello world     '
```

## Running Tests

The project includes comprehensive unit tests developed using TDD principles:

```bash
python test_text_formatter.py
```

## Test Coverage

The tests cover:
- Basic centering functionality for single and two words
- Edge cases (exact fit, odd padding)
- Error handling (line width not set, words too long)
- Various word lengths and line widths

## Development Approach

This project was developed using Test Driven Development (TDD):
1. Tests were written first to define expected behavior
2. Implementation was created to pass the tests
3. Code was refactored while maintaining test coverage

## Error Handling

The class handles various error conditions:
- Raises `ValueError` if line width is not set before formatting
- Raises `ValueError` if words are too long for the specified line width
- Validates input types and values