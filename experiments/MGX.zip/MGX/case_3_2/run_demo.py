#!/usr/bin/env python3
"""
Demo script to showcase TextFormatter functionality.
"""

from text_formatter import TextFormatter


def main():
    """Run demonstration of TextFormatter class."""
    print("=" * 50)
    print("TextFormatter Demo - Test Driven Development")
    print("=" * 50)

    # Create formatter instance
    formatter = TextFormatter()

    # Demo 1: Basic functionality with line width 20
    print("\n1. Basic functionality (line width = 20):")
    formatter.setLineWidth(20)

    single_word = formatter.centerSingleWord("hello")
    two_words = formatter.centerTwoWords("hello", "world")

    print(f"Single word 'hello':      '{single_word}'")
    print(f"Two words 'hello world': '{two_words}'")

    # Demo 2: Different line widths
    print("\n2. Different line widths:")

    for width in [10, 15, 25]:
        formatter.setLineWidth(width)
        result = formatter.centerSingleWord("test")
        print(f"Width {width:2d}: '{result}'")

    # Demo 3: Various word combinations
    print("\n3. Various word combinations (line width = 30):")
    formatter.setLineWidth(30)

    word_pairs = [
        ("a", "b"),
        ("short", "long"),
        ("Python", "TDD"),
        ("test", "driven"),
    ]

    for word1, word2 in word_pairs:
        result = formatter.centerTwoWords(word1, word2)
        print(f"'{word1}' + '{word2}': '{result}'")

    # Demo 4: Edge cases
    print("\n4. Edge cases:")

    # Exact fit
    formatter.setLineWidth(5)
    exact_fit = formatter.centerSingleWord("hello")
    print(f"Exact fit (width=5):     '{exact_fit}'")

    formatter.setLineWidth(11)
    exact_fit_two = formatter.centerTwoWords("hello", "world")
    print(f"Exact fit two words:     '{exact_fit_two}'")

    # Demonstrate error handling
    print("\n5. Error handling examples:")

    try:
        new_formatter = TextFormatter()
        new_formatter.centerSingleWord("test")  # No width set
    except ValueError as e:
        print(f"Error (no width set): {e}")

    try:
        formatter.setLineWidth(5)
        formatter.centerSingleWord("verylongword")  # Word too long
    except ValueError as e:
        print(f"Error (word too long): {e}")

    try:
        formatter.setLineWidth(8)
        formatter.centerTwoWords("hello", "world")  # Combined too long
    except ValueError as e:
        print(f"Error (two words too long): {e}")

    print("\n" + "=" * 50)
    print("Demo completed! Run 'python test_text_formatter.py' to see all tests pass.")
    print("=" * 50)


if __name__ == "__main__":
    main()