"""
Test file for TextFormatter class using Test Driven Development.
This file contains assertions that define the expected behavior before implementation.
"""

import unittest
from text_formatter import TextFormatter


class TestTextFormatter(unittest.TestCase):

    def setUp(self):
        """Set up test fixtures before each test method."""
        self.formatter = TextFormatter()

    def test_set_line_width(self):
        """Test that setLineWidth properly sets the line width."""
        self.formatter.setLineWidth(20)
        self.assertEqual(self.formatter.line_width, 20)

        self.formatter.setLineWidth(50)
        self.assertEqual(self.formatter.line_width, 50)

    def test_center_single_word_basic(self):
        """Test centering a single word in a line."""
        self.formatter.setLineWidth(20)

        # Test with word "hello" (5 chars) in 20-char line
        # Should have (20-5)/2 = 7.5 -> 7 spaces on each side (left-biased)
        result = self.formatter.centerSingleWord("hello")
        expected = "       hello        "  # 7 spaces left, 8 spaces right
        self.assertEqual(result, expected)
        self.assertEqual(len(result), 20)

    def test_center_single_word_exact_fit(self):
        """Test centering a word that exactly fits the line width."""
        self.formatter.setLineWidth(5)
        result = self.formatter.centerSingleWord("hello")
        expected = "hello"
        self.assertEqual(result, expected)
        self.assertEqual(len(result), 5)

    def test_center_single_word_odd_padding(self):
        """Test centering with odd padding (word length and line width difference is odd)."""
        self.formatter.setLineWidth(10)

        # Test with word "hi" (2 chars) in 10-char line
        # Should have (10-2)/2 = 4 spaces on each side
        result = self.formatter.centerSingleWord("hi")
        expected = "    hi    "  # 4 spaces on each side
        self.assertEqual(result, expected)
        self.assertEqual(len(result), 10)

    def test_center_two_words_basic(self):
        """Test centering two words in a line."""
        self.formatter.setLineWidth(20)

        # Test with "hello" and "world" (5+5=10 chars + 1 space = 11 total)
        # Should have (20-11)/2 = 4.5 -> 4 spaces on left, 5 on right
        result = self.formatter.centerTwoWords("hello", "world")
        expected = "    hello world     "  # 4 spaces left, 5 spaces right
        self.assertEqual(result, expected)
        self.assertEqual(len(result), 20)

    def test_center_two_words_exact_fit(self):
        """Test centering two words that exactly fit the line width."""
        self.formatter.setLineWidth(11)
        result = self.formatter.centerTwoWords("hello", "world")
        expected = "hello world"
        self.assertEqual(result, expected)
        self.assertEqual(len(result), 11)

    def test_center_two_words_different_lengths(self):
        """Test centering two words of different lengths."""
        self.formatter.setLineWidth(15)

        # Test with "a" and "test" (1+4=5 chars + 1 space = 6 total)
        # Should have (15-6)/2 = 4.5 -> 4 spaces on left, 5 on right
        result = self.formatter.centerTwoWords("a", "test")
        expected = "    a test     "  # 4 spaces left, 5 spaces right
        self.assertEqual(result, expected)
        self.assertEqual(len(result), 15)

    def test_line_width_not_set_error(self):
        """Test that methods raise error when line width is not set."""
        formatter = TextFormatter()

        with self.assertRaises(ValueError):
            formatter.centerSingleWord("hello")

        with self.assertRaises(ValueError):
            formatter.centerTwoWords("hello", "world")

    def test_word_too_long_error(self):
        """Test that methods handle words longer than line width."""
        self.formatter.setLineWidth(5)

        with self.assertRaises(ValueError):
            self.formatter.centerSingleWord("verylongword")

    def test_two_words_too_long_error(self):
        """Test that centerTwoWords handles words that don't fit."""
        self.formatter.setLineWidth(5)

        with self.assertRaises(ValueError):
            self.formatter.centerTwoWords("hello", "world")


if __name__ == '__main__':
    # Run the tests
    unittest.main()