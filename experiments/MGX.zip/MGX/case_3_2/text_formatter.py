"""
TextFormatter class that centers words horizontally in a line.
Developed using Test Driven Development approach.
"""


class TextFormatter:
    """
    A class that formats text by centering words horizontally in a line of specified width.
    """

    def __init__(self):
        """Initialize the TextFormatter with no line width set."""
        self.line_width = None

    def setLineWidth(self, width):
        """
        Set the width of the line for text formatting.

        Args:
            width (int): The desired width of the line in characters.

        Raises:
            ValueError: If width is not a positive integer.
        """
        if not isinstance(width, int) or width <= 0:
            raise ValueError("Line width must be a positive integer")

        self.line_width = width

    def centerSingleWord(self, word):
        """
        Center a single word in the line.

        Args:
            word (str): The word to center.

        Returns:
            str: The word centered in a line of the specified width.

        Raises:
            ValueError: If line width is not set or word is too long.
        """
        if self.line_width is None:
            raise ValueError("Line width must be set before formatting text")

        if not isinstance(word, str):
            raise ValueError("Word must be a string")

        word_length = len(word)

        if word_length > self.line_width:
            raise ValueError(f"Word '{word}' is too long for line width {self.line_width}")

        if word_length == self.line_width:
            return word

        # Calculate padding
        total_padding = self.line_width - word_length
        left_padding = total_padding // 2
        right_padding = total_padding - left_padding

        return ' ' * left_padding + word + ' ' * right_padding

    def centerTwoWords(self, word1, word2):
        """
        Center two words in the line with a single space between them.

        Args:
            word1 (str): The first word.
            word2 (str): The second word.

        Returns:
            str: The two words centered in a line of the specified width.

        Raises:
            ValueError: If line width is not set or words are too long.
        """
        if self.line_width is None:
            raise ValueError("Line width must be set before formatting text")

        if not isinstance(word1, str) or not isinstance(word2, str):
            raise ValueError("Both words must be strings")

        # Combine words with a space
        combined_text = word1 + ' ' + word2
        combined_length = len(combined_text)

        if combined_length > self.line_width:
            raise ValueError(f"Combined words '{combined_text}' are too long for line width {self.line_width}")

        if combined_length == self.line_width:
            return combined_text

        # Calculate padding
        total_padding = self.line_width - combined_length
        left_padding = total_padding // 2
        right_padding = total_padding - left_padding

        return ' ' * left_padding + combined_text + ' ' * right_padding


# Example usage and demonstration
if __name__ == "__main__":
    # Create formatter instance
    formatter = TextFormatter()

    # Set line width
    formatter.setLineWidth(20)

    # Demonstrate single word centering
    print("Single word examples:")
    print(f"'{formatter.centerSingleWord('hello')}'")
    print(f"'{formatter.centerSingleWord('hi')}'")

    # Demonstrate two words centering
    print("\nTwo words examples:")
    print(f"'{formatter.centerTwoWords('hello', 'world')}'")
    print(f"'{formatter.centerTwoWords('a', 'test')}'")

    # Different line width
    formatter.setLineWidth(15)
    print(f"\nWith line width 15:")
    print(f"'{formatter.centerTwoWords('a', 'test')}'")