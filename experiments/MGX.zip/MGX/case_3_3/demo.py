"""
Demo script to showcase TextFormatter functionality
"""

from text_formatter import TextFormatter


def demo_text_formatter():
    """Demonstrate the TextFormatter class functionality"""

    print("=== TextFormatter Demo ===\n")

    # Create formatter instance
    formatter = TextFormatter()

    # Demo 1: Single word centering
    print("1. Single Word Centering:")
    formatter.setLineWidth(20)
    print(f"Line width: {formatter.line_width}")
    print(f"'{formatter.center_single_word('Hello')}'")
    print(f"'{formatter.center_single_word('Hi')}'")
    print(f"'{formatter.center_single_word('Programming')}'")
    print()

    # Demo 2: Two words centering
    print("2. Two Words Centering:")
    print(f"'{formatter.center_two_words('Hello', 'World')}'")
    print(f"'{formatter.center_two_words('Test', 'Case')}'")
    print(f"'{formatter.center_two_words('Python', 'TDD')}'")
    print()

    # Demo 3: Different line widths
    print("3. Different Line Widths:")

    formatter.setLineWidth(30)
    print(f"Width 30: '{formatter.center_single_word('Centered')}'")
    print(f"Width 30: '{formatter.center_two_words('Two', 'Words')}'")

    formatter.setLineWidth(15)
    print(f"Width 15: '{formatter.center_single_word('Short')}'")
    print(f"Width 15: '{formatter.center_two_words('A', 'B')}'")
    print()

    # Demo 4: Edge cases
    print("4. Edge Cases:")
    formatter.setLineWidth(10)
    print(f"Exact fit: '{formatter.center_single_word('ExactlyTen')}'")
    print(f"Too long:  '{formatter.center_single_word('TooLongForLine')}'")
    print()


if __name__ == "__main__":
    demo_text_formatter()