"""
Test Driven Development for TextFormatter class
Tests written first before implementation
"""


def test_text_formatter():
    """Test cases for TextFormatter class using assertions"""

    # Import the class (will be implemented after tests)
    from text_formatter import TextFormatter

    # Test 1: Basic instantiation
    formatter = TextFormatter()

    # Test 2: setLineWidth function
    formatter.setLineWidth(20)
    assert formatter.line_width == 20, "Line width should be set to 20"

    formatter.setLineWidth(30)
    assert formatter.line_width == 30, "Line width should be updated to 30"

    # Test 3: Single word centering
    formatter.setLineWidth(10)

    # Test with word shorter than line width
    result = formatter.center_single_word("Hi")
    expected = "    Hi    "  # 4 spaces on each side for 10-char line
    assert result == expected, f"Expected '{expected}', got '{result}'"
    assert len(result) == 10, "Result should be exactly 10 characters"

    # Test with odd-length word
    result = formatter.center_single_word("Hello")
    expected = "  Hello   "  # 2 spaces left, 3 spaces right for 10-char line
    assert result == expected, f"Expected '{expected}', got '{result}'"
    assert len(result) == 10, "Result should be exactly 10 characters"

    # Test with word same length as line
    formatter.setLineWidth(5)
    result = formatter.center_single_word("Hello")
    expected = "Hello"
    assert result == expected, f"Expected '{expected}', got '{result}'"

    # Test 4: Two words centering
    formatter.setLineWidth(20)

    # Test with two short words
    result = formatter.center_two_words("Hi", "Bye")
    expected = "      Hi Bye       "  # 6 spaces left, 7 spaces right
    assert result == expected, f"Expected '{expected}', got '{result}'"
    assert len(result) == 20, "Result should be exactly 20 characters"

    # Test with different word lengths
    result = formatter.center_two_words("Hello", "World")
    expected = "    Hello World     "  # 4 spaces left, 5 spaces right
    assert result == expected, f"Expected '{expected}', got '{result}'"
    assert len(result) == 20, "Result should be exactly 20 characters"

    # Test with longer line width
    formatter.setLineWidth(30)
    result = formatter.center_two_words("Test", "Case")
    expected = "           Test Case           "  # 11 spaces on each side
    assert result == expected, f"Expected '{expected}', got '{result}'"
    assert len(result) == 30, "Result should be exactly 30 characters"

    # Edge case: words that fill the line exactly
    formatter.setLineWidth(10)
    result = formatter.center_two_words("Hi", "There")
    expected = " Hi There "  # 1 space left, 1 space right
    assert result == expected, f"Expected '{expected}', got '{result}'"

    print("All tests passed! ✅")


if __name__ == "__main__":
    test_text_formatter()