"""
TextFormatter class implementation
Horizontally centers words in a line of specified width
"""


class TextFormatter:
    """
    A class that formats text by horizontally centering words in a line
    """

    def __init__(self):
        """Initialize TextFormatter with default line width"""
        self.line_width = 80  # Default line width

    def setLineWidth(self, width):
        """
        Set the width of the line for formatting

        Args:
            width (int): The desired line width in characters
        """
        if not isinstance(width, int) or width <= 0:
            raise ValueError("Line width must be a positive integer")
        self.line_width = width

    def center_single_word(self, word):
        """
        Center a single word in the line

        Args:
            word (str): The word to center

        Returns:
            str: The word centered in a line of the specified width
        """
        if not isinstance(word, str):
            raise ValueError("Word must be a string")

        word_length = len(word)

        # If word is longer than line width, return the word as is
        if word_length >= self.line_width:
            return word

        # Calculate padding needed
        total_padding = self.line_width - word_length
        left_padding = total_padding // 2
        right_padding = total_padding - left_padding

        # Create centered string
        return " " * left_padding + word + " " * right_padding

    def center_two_words(self, word1, word2):
        """
        Center two words in the line with a space between them

        Args:
            word1 (str): The first word
            word2 (str): The second word

        Returns:
            str: The two words centered in a line of the specified width
        """
        if not isinstance(word1, str) or not isinstance(word2, str):
            raise ValueError("Both words must be strings")

        # Combine words with a space
        combined = word1 + " " + word2
        combined_length = len(combined)

        # If combined words are longer than line width, return as is
        if combined_length >= self.line_width:
            return combined

        # Calculate padding needed
        total_padding = self.line_width - combined_length
        left_padding = total_padding // 2
        right_padding = total_padding - left_padding

        # Create centered string
        return " " * left_padding + combined + " " * right_padding