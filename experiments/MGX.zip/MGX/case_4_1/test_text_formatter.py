import unittest


class TextFormatter:
    def __init__(self):
        self.line_width = 0

    def setLineWidth(self, width):
        """Sets the length of the line."""
        self.line_width = width

    def center_single_word(self, word):
        """Centers a single word in the line."""
        if len(word) >= self.line_width:
            return word

        total_padding = self.line_width - len(word)
        left_padding = total_padding // 2
        right_padding = total_padding - left_padding

        return ' ' * left_padding + word + ' ' * right_padding

    def center_two_words(self, word_1, word_2):
        """Centers two words in the line."""
        words = [word_1, word_2]
        if len(words) != 2:
            raise ValueError("Expected exactly two words")

        word1, word2 = words
        combined_length = len(word1) + len(word2)

        if combined_length >= self.line_width:
            return word1 + word2

        # Calculate spacing between words and padding
        available_space = self.line_width - combined_length

        if available_space == 1:
            # Only one space available, put it between words
            return word1 + ' ' + word2

        # Distribute remaining space: one space between words, rest as padding
        middle_space = 1
        remaining_space = available_space - middle_space
        left_padding = remaining_space // 2
        right_padding = remaining_space - left_padding

        return ' ' * left_padding + word1 + ' ' * middle_space + word2 + ' ' * right_padding


class TestTextFormatter(unittest.TestCase):

    def setUp(self):
        self.formatter = TextFormatter()

    def test_line_width_10_word_word(self):
        """Test: line width=10 and word="word" """
        # Arrange
        self.formatter.setLineWidth(10)

        # Act
        result = self.formatter.center_single_word("word")

        # Assert
        self.assertEqual(result, "   word   ")
        self.assertEqual(len(result), 10)

    def test_line_width_10_word_hello(self):
        """Test: line width=10 and word="hello" """
        # Arrange
        self.formatter.setLineWidth(10)

        # Act
        result = self.formatter.center_single_word("hello")

        # Assert
        self.assertEqual(result, "  hello   ")
        self.assertEqual(len(result), 10)

    def test_line_width_10_words_foo_bar(self):
        """Test: line width=10 and words=["foo", "bar"] """
        # Arrange
        self.formatter.setLineWidth(10)

        # Act
        result = self.formatter.center_two_words(["foo", "bar"])

        # Assert
        self.assertEqual(result, "  foo bar ")
        self.assertEqual(len(result), 10)


if __name__ == '__main__':
    unittest.main()