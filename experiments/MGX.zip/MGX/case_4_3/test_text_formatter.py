import unittest


class TextFormatter:
    def __init__(self):
        self.line_width = 0

    def setLineWidth(self, width):
        """Sets the length of the line."""
        self.line_width = width

    def format_single_word(self, word):
        """Returns the word centered in the line."""
        if self.line_width <= len(word):
            return word

        padding = self.line_width - len(word)
        left_padding = padding // 2
        right_padding = padding - left_padding

        return ' ' * left_padding + word + ' ' * right_padding

    def format_two_words(self, word_1, word_2):
        """Centers two words in the line."""
        words = [word_1, word_2]
        if len(words) != 2:
            raise ValueError("Expected exactly two words")

        word1, word2 = words
        combined_length = len(word1) + len(word2) + 1  # +1 for space between words

        if self.line_width <= combined_length:
            return word1 + ' ' + word2

        padding = self.line_width - combined_length
        left_padding = padding // 2
        right_padding = padding - left_padding

        return ' ' * left_padding + word1 + ' ' + word2 + ' ' * right_padding


class TestTextFormatter(unittest.TestCase):

    def setUp(self):
        self.formatter = TextFormatter()

    def test_line_width_10_word_word(self):
        """Test case: line width=10 and word="word" """
        self.formatter.setLineWidth(10)
        result = self.formatter.format_single_word("word")
        self.assertEqual(result, "   word   ")
        self.assertEqual(len(result), 10)

    def test_line_width_10_word_hello(self):
        """Test case: line width=10 and word="hello" """
        self.formatter.setLineWidth(10)
        result = self.formatter.format_single_word("hello")
        self.assertEqual(result, "  hello   ")
        self.assertEqual(len(result), 10)

    def test_line_width_10_words_foo_bar(self):
        """Test case: line width=10 and words=["foo", "bar"] """
        self.formatter.setLineWidth(10)
        result = self.formatter.format_two_words(["foo", "bar"])
        self.assertEqual(result, " foo bar  ")
        self.assertEqual(len(result), 10)


if __name__ == '__main__':
    unittest.main()