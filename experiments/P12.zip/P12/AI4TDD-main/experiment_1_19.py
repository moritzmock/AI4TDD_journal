class TextFormatter:
    def __init__(self, line_width):
        self.line_width = line_width

    def centerWord(self, word):
        word_len = len(word)
        spaces_to_add = (self.line_width - word_len) // 2

        # If the line width is odd, add an extra space before the word
        if self.line_width % 2 != 0:
            return " " * (spaces_to_add + 1) + word + " " * spaces_to_add

        return " " * spaces_to_add + word + " " * spaces_to_add





import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("   passa   ", textFormatter.centerWord("passa"))

if __name__ == "__main__":
  unittest.main()
