class TextFormatter:
    def __init__(self, line_width):
        self.line_width = line_width

    def centerWord(self, word):
        word_len = len(word)
        spaces_to_add = (self.line_width - word_len) // 2

        # Add one extra space if the word length is odd
        if word_len % 2 != 0:
            spaces_to_add += 1

        return " " * spaces_to_add + word + " " * spaces_to_add

    def equalSpread(self, word1, word2):
        total_word_len = len(word1) + len(word2)
        spaces_to_add = (self.line_width - total_word_len) // 3
        leftover_spaces = (self.line_width - total_word_len) % 3

        return " " * spaces_to_add + word1 + " " * spaces_to_add + " " * (spaces_to_add + leftover_spaces) + word2 + " " * spaces_to_add




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("  passa   ", textFormatter.centerWord("passa"))

  def test_WordCenterOdd(self):
    textFormatter = TextFormatter(9)
    self.assertEqual("  passa  ", textFormatter.centerWord("passa"))

  def test_TwoWordSpreadEven(self):
    TextFormatter = TextFormatter(10)
    self.assertEqual("  eu  ou  ", TextFormatter.equalSpread("eu", "ou"))

  def test_TwoWordSpreadOdd(self):
    textFormatter = TextFormatter(11)
    self.assertEqual("  eu   ou  ", TextFormatter.equalSpread("eu", "ou"))

if __name__ == "__main__":
  unittest.main()
