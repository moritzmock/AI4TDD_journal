class TextFormatter:
    def __init__(self, total_width):
        self.total_width = total_width

    def centerWord(self, word):
        padding = (self.total_width - len(word)) // 2
        return " " * padding + word + " " * padding
    
    def equalSpread(self, word1, word2):
        space_width = (self.total_width - len(word1) - len(word2)) // 2
        return " " * space_width + word1 + " " * space_width + word2




import unittest


class TestTextFormatter(unittest.TestCase):

  def test_WordCenterEven(self):
    textFormatter = TextFormatter(10)
    self.assertEqual("  passa   ", textFormatter.centerWord("passa"))

  def test_WordCenterOdd(self):
    textFormatter = TextFormatter(9)
    self.assertEqual("  passa  ", textFormatter.centerWord("passa"))

  def test_TwoWordSpreadEven(self):
    TextFormatter = TextFormatter(10)
    self.assertEqual("  eu  ou  ", TextFormatter.equalSpread("eu", "ou"))

  def test_TwoWordSpreadOdd(self):
    textFormatter = TextFormatter(11)
    self.assertEqual("  eu   ou  ", TextFormatter.equalSpread("eu", "ou"))

if __name__ == "__main__":
  unittest.main()
