class TooLongError(Exception):
    pass


class TextFormatter:
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, lineWidth):
        if lineWidth <= 0:
            raise ValueError("Line width must be a positive integer")
        self.lineWidth = lineWidth
        return self.lineWidth

    def centerWordInLine(self, word):
        if len(word) > self.lineWidth:
            raise ValueError("Word length exceeds line width")
        left_padding = (self.lineWidth - len(word)) // 2
        right_padding = self.lineWidth - len(word) - left_padding
        
        return " " * left_padding + word + " " * right_padding

    def splitWordsInLine(self, word1, word2):
        line = word1 + " " * (self.lineWidth - len(word1) - len(word2)) + word2
        if len(line) > self.lineWidth:
            raise TooLongError("Line width exceeded")
        return line




import unittest


class ExampleTestCase(unittest.TestCase):


    def test_line_width(self):

        tF = TextFormatter()
      
        self.assertEqual(tF.setLineWidth(1), tF.lineWidth)

        self.assertEqual(tF.setLineWidth(1000), tF.lineWidth)

        with self.assertRaises(ValueError):
            tF.setLineWidth(0)

        with self.assertRaises(ValueError):
            tF.setLineWidth(-1)

        with self.assertRaises(TypeError):
            tF.setLineWidth("Chicken")

    def test_center(self):

        tF = TextFormatter()

        tF.setLineWidth(3)

        self.assertEqual(tF.centerWordInLine("a"), " a ")

        tF.setLineWidth(4)

        self.assertEqual(tF.centerWordInLine("a"), " a  ")

        tF.setLineWidth(2)

        self.assertEqual(tF.centerWordInLine("a"), "a ")

        with self.assertRaises(ValueError):
            tF.centerWordInLine("Someone else")

        tF.setLineWidth(8)

        self.assertEqual(tF.centerWordInLine("abcd"), "  abcd  ")


    def test_split_words_in_line(self):

        tF = TextFormatter()

        tF.setLineWidth(3)

        self.assertEqual(tF.splitWordsInLine("a", "b"), "a b")
        self.assertEqual(tF.splitWordsInLine("ab", "c"), "abc")
        with self.assertRaises(TooLongError):
            tF.splitWordsInLine("ab", "cd")

        tF.setLineWidth(6)

        self.assertEqual(tF.splitWordsInLine("ab", "cde"), "ab cde")

        tF.setLineWidth(4)

        self.assertEqual(tF.splitWordsInLine("a", "b"), "a  b")

        tF.setLineWidth(2)

        self.assertEqual(tF.splitWordsInLine("a", "b"), "ab")

        with self.assertRaises(TooLongError):
            tF.splitWordsInLine("Python", "Javascript")

        
        with self.assertRaises(TypeError):
            tF.splitWordsInLine(1, tF)

if __name__ == "__main__":
    unittest.main()