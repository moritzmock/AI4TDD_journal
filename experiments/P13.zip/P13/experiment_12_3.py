class TextFormatter:
    def __init__(self):
        self.lineWidth = None

    def setLineWidth(self, width):
        if width <= 0:
            raise ValueError("Line width must be a positive integer")
        self.lineWidth = width
        return self.lineWidth

    def centerWordInLine(self, word):
        if len(word) > self.lineWidth:
            raise ValueError("Word is longer than line width")
        spaces = (self.lineWidth - len(word)) // 2
        return " " * spaces + word + " " * spaces

    def splitWordsInLine(self, word1, word2):
        line = word1 + " " + word2
        if len(line) > self.lineWidth:
            raise ValueError("Combined words is longer than line width")
        return line




import unittest


class ExampleTestCase(unittest.TestCase):


    def test_line_width(self):

        tF = TextFormatter()
      
        self.assertEqual(tF.setLineWidth(1), tF.lineWidth)

        self.assertEqual(tF.setLineWidth(1000), tF.lineWidth)

        with self.assertRaises(ValueError):
            tF.setLineWidth(0)

        with self.assertRaises(ValueError):
            tF.setLineWidth(-1)

    def test_center(self):

        tF = TextFormatter()

        tF.setLineWidth(3)

        self.assertEqual(tF.centerWordInLine("a"), " a ")

        tF.setLineWidth(4)

        self.assertEqual(tF.centerWordInLine("a"), " a  ")

        tF.setLineWidth(2)

        self.assertEqual(tF.centerWordInLine("a"), "a ")

        with self.assertRaises(ValueError):
            tF.centerWordInLine("Moritz")

    def test_split_words_in_line(self):

        tF = TextFormatter()

        tF.setLineWidth(3)

        self.assertEqual(tF.splitWordsInLine("a", "b"), "a b")

        tF.setLineWidth(4)

        self.assertEqual(tF.splitWordsInLine("a", "b"), "a  b")

        tF.setLineWidth(2)

        self.assertEqual(tF.splitWordsInLine("a", "b"), "ab")

        with self.assertRaises(SomeError):
            tF.splitWordsInLine("Moritz", "Javascript")

if __name__ == "__main__":
    unittest.main()