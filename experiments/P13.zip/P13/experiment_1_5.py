import unittest


class ExampleTestCase(unittest.TestCase):

    tF = TextFormatter()

    def test_example(self):
      
        self.assertEqual(tF.setLineWidth(1), tF.lineWidth)


if __name__ == "__main__":
    unittest.main()