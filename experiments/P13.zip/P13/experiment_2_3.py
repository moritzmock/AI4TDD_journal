class TextFormatter:
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width
        return self.lineWidth



import unittest


class ExampleTestCase(unittest.TestCase):

    def test_example(self):
        tF = TextFormatter()
        self.assertEqual(tF.setLineWidth(1), tF.lineWidth)


if __name__ == "__main__":
    unittest.main()




class ExampleTestCase(unittest.TestCase):

    tF = TextFormatter()

    def test_example(self):
      
        self.assertEqual(tF.setLineWidth(1), tF.lineWidth)


if __name__ == "__main__":
    unittest.main()