class TextFormatter:
    def setLineWidth(self, lineWidth):
        if lineWidth <= 0:
            raise ValueError("Line width must be a positive integer")
        self.lineWidth = lineWidth




import unittest


class ExampleTestCase(unittest.TestCase):


    def test_example(self):

        tF = TextFormatter()
      
        self.assertEqual(tF.setLineWidth(1), tF.lineWidth)

        with self.assertRaises(ValueError):
            tF.setLineWidth(0)

        with self.assertRaises(ValueError):
            tF.setLineWidth(-1)


if __name__ == "__main__":
    unittest.main()