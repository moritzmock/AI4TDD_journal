class TextFormatter:
    def __init__(self):
        self.lineWidth = None

    def setLineWidth(self, width):
        if width <= 0:
            raise ValueError("Width should be a positive integer.")
        self.lineWidth = width
        return self.lineWidth




import unittest


class ExampleTestCase(unittest.TestCase):


    def test_example(self):

        tF = TextFormatter()
      
        self.assertEqual(tF.setLineWidth(1), tF.lineWidth)

        with self.assertRaises(ValueError):
            tF.setLineWidth(0)

        with self.assertRaises(ValueError):
            tF.setLineWidth(-1)


if __name__ == "__main__":
    unittest.main()