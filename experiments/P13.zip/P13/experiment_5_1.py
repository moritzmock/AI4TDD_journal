class TextFormatter:
    def __init__(self):
        self.lineWidth = None

    def setLineWidth(self, width):
        if width < 1:
            raise ValueError("Line width should be greater than or equal to 1")
        self.lineWidth = width

    def centerWordInLine(self, word):
        if self.lineWidth is None:
            raise ValueError("Line width is not set")
        padding = (self.lineWidth - len(word)) // 2
        return " " * padding + word + " " * padding




import unittest


class ExampleTestCase(unittest.TestCase):


    def test_line_width(self):

        tF = TextFormatter()
      
        self.assertEqual(tF.setLineWidth(1), tF.lineWidth)

        with self.assertRaises(ValueError):
            tF.setLineWidth(0)

        with self.assertRaises(ValueError):
            tF.setLineWidth(-1)

    def test_center(self):

        tF = TextFormatter()

        tF.setLineWidth(3)

        self.assertEqual(tF.centerWordInLine("a"), " a ")


if __name__ == "__main__":
    unittest.main()