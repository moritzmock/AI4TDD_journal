class TextFormatter:
    def __init__(self):
        self.lineWidth = None

    def setLineWidth(self, width):
        if width < 1:
            raise ValueError("Width must be greater than or equal to 1")
        
        self.lineWidth = width

    def centerWordInLine(self, word):
        if len(word) > self.lineWidth:
            raise ValueError("Word cannot be longer than the line width")

        padding = (self.lineWidth - len(word)) // 2
        return " " * padding + word + " " * padding




import unittest


class ExampleTestCase(unittest.TestCase):


    def test_line_width(self):

        tF = TextFormatter()
      
        self.assertEqual(tF.setLineWidth(1), tF.lineWidth)

        with self.assertRaises(ValueError):
            tF.setLineWidth(0)

        with self.assertRaises(ValueError):
            tF.setLineWidth(-1)

        with self.assertRaises(TypeError):
            tF.setLineWidth("Chicken")

    def test_center(self):

        tF = TextFormatter()

        tF.setLineWidth(3)

        self.assertEqual(tF.centerWordInLine("a"), " a ")

        tF.setLineWidth(4)

        self.assertEqual(tF.centerWordInLine("a"), " a  ")

        tF.setLineWidth(2)

        self.assertEqual(tF.centerWordInLine("a"), "a ")

        with self.assertRaises(ValueError):
            tF.centerWordInLine("Moritz")


if __name__ == "__main__":
    unittest.main()