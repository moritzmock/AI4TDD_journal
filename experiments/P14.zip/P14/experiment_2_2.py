class TextFormatter:
    def __init__(self):
        self.lineWidth = None

    def setLineWidth(self, width):
        self.lineWidth = width

    def alignCenter(self, text):
        if self.lineWidth is None:
            raise ValueError("Line width is not set")

        if len(text) >= self.lineWidth:
            return text

        padding = (self.lineWidth - len(text)) // 2
        formattedText = " " * padding + text + " " * padding
        return formattedText




import unittest


class ExampleTestCase(unittest.TestCase):

    def test_example(self):
        self.assertEqual(1, 1)

    def testSetLineWidthExists(self):
      try:
        input_set = {10, 20, 30}
        tf = TextFormatter()
        tf.setLineWidth(input_set)
      except Exception as e:
        self.fail(f"setLineWidth raised an exception: {e}")

    def testLineLength(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        formattedText = tf.alignCenter("home")
        self.assertCountEqual(len(formattedText), 10)



if __name__ == "__main__":
    unittest.main()