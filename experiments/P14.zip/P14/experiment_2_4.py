class TextFormatter:
    def __init__(self):
        self.line_width = None

    def setLineWidth(self, width):
        if not isinstance(width, int) or width <= 0:
            raise ValueError("Invalid line width value.")
        self.line_width = width

    def alignCenter(self, text):
        if self.line_width is None:
            raise ValueError("Line width not set.")
        if len(text) > self.line_width:
            raise ValueError("Text length is greater than line width.")

        padding = (self.line_width - len(text)) // 2
        return " " * padding + text + " " * padding






import unittest


class ExampleTestCase(unittest.TestCase):

    def test_example(self):
        self.assertEqual(1, 1)

    def testSetLineWidthExists(self):
      try:
        input_set = {10, 20, 30}
        tf = TextFormatter()
        tf.setLineWidth(input_set)
      except Exception as e:
        self.fail(f"setLineWidth raised an exception: {e}")

    def testLineLength(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        formattedText = tf.alignCenter("home")
        self.assertCountEqual(len(formattedText), 10)



if __name__ == "__main__":
    unittest.main()