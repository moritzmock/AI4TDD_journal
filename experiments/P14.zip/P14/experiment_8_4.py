class TextFormatter:
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def alignCenter(self, text):
        if self.lineWidth == 0:
            raise ValueError("Line width needs to be set before aligning the text")
        
        if len(text) >= self.lineWidth:
            return text
        
        left_space = (self.lineWidth - len(text)) // 2
        right_space = self.lineWidth - len(text) - left_space
        
        formatted_text = " " * left_space + text + " " * right_space
        return formatted_text

    def alignSpread(self, sentence):
        if self.lineWidth == 0:
            raise ValueError("Line width needs to be set before aligning the text")

        if len(sentence) >= self.lineWidth:
            return sentence
        
        left_space = (self.lineWidth - len(sentence)) // 2
        right_space = self.lineWidth - len(sentence) - left_space

        formatted_text = sentence + " " * right_space
        formatted_text = " " * left_space + formatted_text
        return formatted_text




import unittest


class ExampleTestCase(unittest.TestCase):

    def test_example(self):
        self.assertEqual(1, 1)

    def testSetLineWidthExists(self):
      try:
        input_set = {10, 20, 30}
        tf = TextFormatter()
        tf.setLineWidth(input_set)
      except Exception as e:
        self.fail(f"setLineWidth raised an exception: {e}")

    def testLineLength(self):
        tf = TextFormatter()
        tf.setLineWidth(10)
        formattedText = tf.alignCenter("home")
        self.assertEqual(len(formattedText), 10)

    def testIsCenteredPair(self):
        tf = TextFormatter()
        lineLength = 10
        word = "home"
        tf.setLineWidth(lineLength)
        formattedText = tf.alignCenter(word)
        self.assertEqual(formattedText[:3], "   ")
        self.assertEqual(formattedText[7:], "   ")
      
    def testIsCenteredOdd(self):
        tf = TextFormatter()
        lineLength = 10
        word = "house"
        tf.setLineWidth(lineLength)
        formattedText = tf.alignCenter(word)
        self.assertEqual(formattedText[:2], "  ")
        self.assertEqual(formattedText[8:], "  ")
    
    def testBeginEndNotBlank(self):
        tf = TextFormatter()
        lineLength = 10
        sentence = "I do"
        tf.setLineWidth(lineLength)
        formattedText = tf.alignSpread(sentence)
        self.assertEqual(formattedText[:1], "I")
        self.assertEqual(formattedText[10:], "o")


  


if __name__ == "__main__":
    unittest.main()