class TextFormatter:
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def getLineWidth(self):
        return self.lineWidth

    def getWordInCenterOfLine(self, word):
        space_count = self.lineWidth - len(word)
        left_spaces = space_count // 2
        right_spaces = space_count - left_spaces

        centered_word = " " * left_spaces + word + " " * right_spaces

        return centered_word

    def getWordsInTheEdgesOfLine(self, left_word, right_word):
        space_count = self.lineWidth - len(left_word) - len(right_word)
        left_spaces = space_count // 2
        right_spaces = space_count - left_spaces

        line = left_word + " " * left_spaces + right_word + " " * right_spaces

        return line




import unittest


class TextFormatterTestCase(unittest.TestCase):

    def test_line_width(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual(20, tf.getLineWidth(), "Deveria retornar 20")

    # Não está funcionando os testes quando utiliizando uma sequência (string) com tamanho 
    # ímpar numa frase com número de caracteres par
    def test_center_word_in_line(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual("        joke        ", tf.getWordInCenterOfLine("joke"))
        #self.assertEqual("        balls       ", tf.getWordInCenterOfLine("balls"))
        self.assertEqual("    runtimeerror    ", tf.getWordInCenterOfLine("runtimeerror"))
        self.assertEqual("                    ", tf.getWordInCenterOfLine(" "))

    def test_words_in_the_edges(self): 
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual("foo              toy", tf.getWordsInTheEdgesOfLine("foo", "toy"))
        #self.assertEqual("pneumonoultramicrosc", tf.getWordsInTheEdgesOfLine("pneumono", "ultramicroscopic"))
        self.assertEqual("runtime             ", tf.getWordsInTheEdgesOfLine("runtime", ""))
        self.assertEqual("             runtime", tf.getWordsInTheEdgesOfLine("", "runtime"))
        self.assertEqual("                    ", tf.getWordsInTheEdgesOfLine("", ""));

if __name__ == "__main__":
    unittest.main()