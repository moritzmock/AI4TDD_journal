class TextFormatter:
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def getLineWidth(self):
        return self.lineWidth



import unittest


class TextFormatterTestCase(unittest.TestCase):

    def test_example(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual(20, tf.getLineWidth(), "Deveria retornar 20")

if __name__ == "__main__":
    unittest.main()