class TextFormatter:
    def __init__(self):
        self.line_width = 0

    def setLineWidth(self, width):
        self.line_width = width

    def getLineWidth(self):
        return self.line_width

    def getWordInCenter(self, word):
        padding_size = (self.line_width - len(word)) // 2
        padding = " " * padding_size
        centered_word = padding + word + padding
        return centered_word





import unittest


class TextFormatterTestCase(unittest.TestCase):

    def test_line_width(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual(20, tf.getLineWidth(), "Deveria retornar 20")

    def test_center_word_in_line(self):
        self.assertEqual("        joke        ", tf.getWordInCenter("joke"))
        self.assertEqual("        balls       ", tf.getWordInCenter("balls"))
        self.assertEqual("    runtimeerror    ", tf.getWordInCenter("runtimeerror"))

if __name__ == "__main__":
    unittest.main()