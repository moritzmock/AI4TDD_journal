class TextFormatter:
    def __init__(self):
        self.line_width = 0

    def setLineWidth(self, width):
        self.line_width = width

    def getLineWidth(self):
        return self.line_width

    def getWordInCenterOfLine(self, word):
        word_length = len(word)
        total_space = self.line_width - word_length
        prefix_space = total_space // 2
        suffix_space = total_space - prefix_space
        return " " * prefix_space + word + " " * suffix_space



import unittest


class TextFormatterTestCase(unittest.TestCase):

    def test_line_width(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual(20, tf.getLineWidth(), "Deveria retornar 20")

    def test_center_word_in_line(self):
        tf = TextFormatter();
        self.assertEqual("        joke        ", tf.getWordInCenterOfLine("joke"))
        self.assertEqual("        balls       ", tf.getWordInCenterOfLine("balls"))
        self.assertEqual("    runtimeerror    ", tf.getWordInCenterOfLine("runtimeerror"))

if __name__ == "__main__":
    unittest.main()