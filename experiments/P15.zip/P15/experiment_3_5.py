class TextFormatter():
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, lineWidth):
        self.lineWidth = lineWidth

    def getLineWidth(self):
        return self.lineWidth

    def getWordInCenterOfLine(self, word):
        line_width = self.getLineWidth()

        if len(word) >= line_width:
            return word
        
        padding = " " * ((line_width - len(word)) // 2)
        centered_word = padding + word + padding
        
        if len(centered_word) < line_width:
            centered_word += " "
        
        return centered_word



import unittest


class TextFormatterTestCase(unittest.TestCase):

    def test_line_width(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual(20, tf.getLineWidth(), "Deveria retornar 20")

    def test_center_word_in_line(self):
        tf = TextFormatter();
        self.assertEqual("        joke        ", tf.getWordInCenterOfLine("joke"))
        self.assertEqual("        balls       ", tf.getWordInCenterOfLine("balls"))
        self.assertEqual("    runtimeerror    ", tf.getWordInCenterOfLine("runtimeerror"))

if __name__ == "__main__":
    unittest.main()