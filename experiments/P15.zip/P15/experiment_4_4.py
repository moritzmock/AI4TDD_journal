class TextFormatter:
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def getLineWidth(self):
        return self.lineWidth

    def getWordInCenterOfLine(self, word):
        whitespace_count = self.lineWidth - len(word)
        left_whitespace_count = whitespace_count // 2
        right_whitespace_count = whitespace_count - left_whitespace_count
        return " " * left_whitespace_count + word + " " * right_whitespace_count



import unittest


class TextFormatterTestCase(unittest.TestCase):

    def test_line_width(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual(20, tf.getLineWidth(), "Deveria retornar 20")

    def test_center_word_in_line(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual("        joke        ", tf.getWordInCenterOfLine("joke"))
        self.assertEqual("        balls       ", tf.getWordInCenterOfLine("balls"))
        self.assertEqual("    runtimeerror    ", tf.getWordInCenterOfLine("runtimeerror"))
        
if __name__ == "__main__":
    unittest.main()