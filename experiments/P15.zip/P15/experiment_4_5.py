class TextFormatter:
    def __init__(self):
        self.lineWidth = 0
    
    def setLineWidth(self, width):
        self.lineWidth = width
    
    def getLineWidth(self):
        return self.lineWidth
    
    def getWordInCenterOfLine(self, word):
        line_width = self.getLineWidth()
        word_length = len(word)
        
        if word_length >= line_width:
            return word
        
        padding_length = (line_width - word_length) // 2
        left_padding = ' ' * padding_length
        right_padding = ' ' * (line_width - word_length - padding_length)
        
        centered_word = left_padding + word + right_padding
        return centered_word



import unittest


class TextFormatterTestCase(unittest.TestCase):

    def test_line_width(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual(20, tf.getLineWidth(), "Deveria retornar 20")

    def test_center_word_in_line(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual("        joke        ", tf.getWordInCenterOfLine("joke"))
        self.assertEqual("        balls       ", tf.getWordInCenterOfLine("balls"))
        self.assertEqual("    runtimeerror    ", tf.getWordInCenterOfLine("runtimeerror"))
        
if __name__ == "__main__":
    unittest.main()