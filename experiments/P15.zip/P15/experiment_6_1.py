class TextFormatter:
    def __init__(self):
        self.line_width = 0

    def setLineWidth(self, width):
        self.line_width = width

    def getLineWidth(self):
        return self.line_width

    def getWordInCenterOfLine(self, word):
        padding = (self.line_width - len(word)) // 2
        center_word = ' ' * padding + word + ' ' * padding
        if len(center_word) < self.line_width:
            center_word += ' ' * (self.line_width - len(center_word))
        return center_word





import unittest


class TextFormatterTestCase(unittest.TestCase):

    def test_line_width(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual(20, tf.getLineWidth(), "Deveria retornar 20")

    def test_center_word_in_line(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual("        joke        ", tf.getWordInCenterOfLine("joke"))
        self.assertEqual("        truck       ", tf.getWordInCenterOfLine("truck"))
        self.assertEqual("    runtimeerror    ", tf.getWordInCenterOfLine("runtimeerror"))
        self.assertEqual("                    ", tf.getWordInCenterOfLine(" "))
        

if __name__ == "__main__":
    unittest.main()