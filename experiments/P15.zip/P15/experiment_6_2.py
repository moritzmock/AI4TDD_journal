class TextFormatter:
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def getLineWidth(self):
        return self.lineWidth

    def getWordInCenterOfLine(self, word):
        line_width = self.getLineWidth()
        word_width = len(word)

        if word_width >= line_width:
            return word  # Word is wider than or equal to the line width, no need to center

        padding_width = (line_width - word_width) // 2
        left_padding = ' ' * padding_width
        right_padding = ' ' * (line_width - word_width - padding_width)

        return left_padding + word + right_padding



import unittest


class TextFormatterTestCase(unittest.TestCase):

    def test_line_width(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual(20, tf.getLineWidth(), "Deveria retornar 20")

    def test_center_word_in_line(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual("        joke        ", tf.getWordInCenterOfLine("joke"))
        self.assertEqual("        truck       ", tf.getWordInCenterOfLine("truck"))
        self.assertEqual("    runtimeerror    ", tf.getWordInCenterOfLine("runtimeerror"))
        self.assertEqual("                    ", tf.getWordInCenterOfLine(" "))
        

if __name__ == "__main__":
    unittest.main()