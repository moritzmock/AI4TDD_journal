class TextFormatter:
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def getLineWidth(self):
        return self.lineWidth

    def getWordInCenterOfLine(self, word):
        line_width = self.getLineWidth()
        if line_width <= len(word):
            return word
        else:
            padding = (line_width - len(word)) // 2
            return " " * padding + word + " " * padding



import unittest


class TextFormatterTestCase(unittest.TestCase):

    def test_line_width(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual(20, tf.getLineWidth(), "Deveria retornar 20")

    def test_center_word_in_line(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual("        joke        ", tf.getWordInCenterOfLine("joke"))
        self.assertEqual("        truck       ", tf.getWordInCenterOfLine("truck"))
        self.assertEqual("    runtimeerror    ", tf.getWordInCenterOfLine("runtimeerror"))
        self.assertEqual("                    ", tf.getWordInCenterOfLine(" "))
        

if __name__ == "__main__":
    unittest.main()