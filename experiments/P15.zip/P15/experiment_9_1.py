class TextFormatter:
    def __init__(self):
        self.lineWidth = 0

    def setLineWidth(self, width):
        self.lineWidth = width

    def getLineWidth(self):
        return self.lineWidth

    def getWordInCenterOfLine(self, word):
        space_count = self.lineWidth - len(word)
        left_spaces = space_count // 2
        right_spaces = space_count - left_spaces

        centered_word = " " * left_spaces + word + " " * right_spaces

        if space_count % 2 != 0:
          centered_word += " "

        return centered_word




import unittest


class TextFormatterTestCase(unittest.TestCase):

    def test_line_width(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual(20, tf.getLineWidth(), "Deveria retornar 20")

    def test_center_word_in_line(self):
        tf = TextFormatter();
        tf.setLineWidth(20);
        self.assertEqual("        joke        ", tf.getWordInCenterOfLine("joke"))
        self.assertEqual("        truck       ", tf.getWordInCenterOfLine("truck"))
        self.assertEqual("    runtimeerror    ", tf.getWordInCenterOfLine("runtimeerror"))
        self.assertEqual("                    ", tf.getWordInCenterOfLine(" "))
        

if __name__ == "__main__":
    unittest.main()