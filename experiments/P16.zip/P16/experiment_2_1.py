class TextFormatter:
    def setLineWidth(self, width):
        # Implement the logic to set the line width
        pass

    def findCentralWord(self, word):
        if len(word) % 2 == 0:
            return word[len(word) // 2 - 1: len(word) // 2 + 1]
        else:
            return word[len(word) // 2]




import unittest


class ExampleTestCase(unittest.TestCase):

    def test_example(self):
        tf = TextFormatter()
        self.assertEqual(None, tf.setLineWidth(5))

    def test_example(self):
        tf = TextFormatter()
        self.assertEqual("pannocchia", tf.findCentralWord("pannocchia"))


if __name__ == "__main__":
    unittest.main()