class TextFormatter:
    def setLineWidth(self, width):
        # Implement the logic to set the line width

    def findCentralWord(self, word):
        if len(word) % 2 == 0:
            central_index = len(word) // 2 - 1
            return word[central_index: central_index + 2]
        else:
            central_index = len(word) // 2
            return word[central_index]




import unittest


class ExampleTestCase(unittest.TestCase):

    def test_example(self):
        tf = TextFormatter()
        self.assertEqual(None, tf.setLineWidth(5))

    def test_example(self):
        tf = TextFormatter()
        self.assertEqual("pannocchia", tf.findCentralWord("pannocchia"))


if __name__ == "__main__":
    unittest.main()