class TextFormatter:
    def setLineWidth(self, width):
        # Implement the logic to set the line width
        pass
    
    def findCentralWord(self, word):
        length = len(word)
        
        # If the word length is odd, return the middle character
        if length % 2 == 1:
            return word[length // 2]
        
        # If the word length is even, return the two middle characters
        middle = length // 2
        return word[middle - 1:middle + 1]






import unittest


class ExampleTestCase(unittest.TestCase):

    def test_example(self):
        tf = TextFormatter()
        self.assertEqual(None, tf.setLineWidth(5))

    def test_example(self):
        tf = TextFormatter()
        self.assertEqual("pannocchia", tf.findCentralWord("pannocchia"))


if __name__ == "__main__":
    unittest.main()