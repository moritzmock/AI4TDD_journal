class TextFormatter:
    def setLineWidth(self, width):
        # Implement the logic to set the line width
        pass

    def findCentralWord(self, text):
        words = text.split()
        word_count = len(words)
        middle_index = word_count // 2
        return words[middle_index]






import unittest


class ExampleTestCase(unittest.TestCase):

    def test_example(self):
        tf = TextFormatter()
        self.assertEqual(None, tf.setLineWidth(5))

    def test_example(self):
        tf = TextFormatter()
        self.assertEqual("pannocchia", tf.findCentralWord("pannocchia"))


if __name__ == "__main__":
    unittest.main()