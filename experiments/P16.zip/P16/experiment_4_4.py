class TextFormatter:
    def setLineWidth(self, width):
        return width
    
    def findCentralWord(self, text):
        words = text.split()
        word_count = len(words)
        middle_index = word_count // 2
        return words[middle_index]
        
    def spreadWords(self, text, width):
        words = text.split()
        if len(words) == 1:
            return text
          
        total_spaces = width - sum([len(word) for word in words])
        space_count = len(words) - 1
        
        if space_count == 0:
            spread_text = words[0]
        else:
            spaces_per_word = total_spaces // space_count
            extra_spaces = total_spaces % space_count
            spread_text = words[0]
            
            for i in range(1, len(words)):
                spacing = " " * spaces_per_word
                if extra_spaces > 0:
                    spacing += " "
                    extra_spaces -= 1
                spread_text += spacing + words[i]
        
        return spread_text






import unittest


class ExampleTestCase(unittest.TestCase):

    def test_example(self):
        tf = TextFormatter()
        self.assertEqual(None, tf.setLineWidth(5))

    def test_example(self):
        tf = TextFormatter()
        self.assertEqual("pannocchia", tf.findCentralWord("pannocchia"))

    def test_example(self):
        tf = TextFormatter()
        self.assertEqual("pannocchia    gialla", tf.spreadWords("pannocchia gialla", 20))

    def test_example(self):
        tf = TextFormatter()
        self.assertEqual("pannocchia    gialla", tf.spreadWords("pannocchia gialla", tf.setLineWidth(20)))

if __name__ == "__main__":
    unittest.main()