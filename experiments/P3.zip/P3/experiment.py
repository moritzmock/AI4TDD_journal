import unittest

class TextFormatter():
  def setLineWidth(self, width):
    self.width = width
  
  def singleWord(self, word):
    if len(word) > self.width:
      raise ValueError("String is too long")

    return f'{word: ^{self.width}}'.format(word)

  def twoWords(self, word1, word2):
    if len(word1) + len(word2) > self.width:
       raise ValueError("String is too long")
    return f"{word1:<10}"[:-len(word2)] + word2


class ExampleTestCase(unittest.TestCase):

    def test_setter(self):
        c = TextFormatter()
        c.setLineWidth(10)

        self.assertEqual(c.width, 10)
    
    def test_single_word(self):
        c = TextFormatter()
        c.setLineWidth(10)

        res = c.singleWord("miao")
        self.assertEqual(len(res), 10)
        self.assertEqual(res, "   miao   ")
    
    def test_two_words(self):
        c = TextFormatter()
        c.setLineWidth(10)

        res = c.twoWords("miao","miao")
        self.assertEqual(len(res), 10)
        self.assertEqual(res, "miao  miao")
    
    def test_error(self):
        c = TextFormatter()
        c.setLineWidth(2)
        with self.assertRaises(ValueError) as cm:
             c.singleWord("miao")
             c.twoWords("miao","miao")
        




if __name__ == "__main__":
    unittest.main()