import unittest

class TextFormatter():
  line_width = 0

  def setLineWidth(self, width):
    self.line_width = width
  
  def getLineWidth(self):
    return self.line_width

  def center(self, word):
    if len(word) > self.line_width:
      raise Exception("word too long!")

    return word.center(self.line_width,' ')
  
  def spread(self, word1, word2):
    if len(word) > self.line_width:
      raise Exception("word too long!")
    nspaces = self.line_width - len(word1) - len(word2)
    return word1 + ' '*nspaces + word2


class ExampleTestCase(unittest.TestCase):
    centered = "                       ciao                       "
    spreaded = "ciao                                          ciao"

    def test(self):
        tf = TextFormatter()
        tf.setLineWidth(5)
        self.assertEqual(tf.getLineWidth(), 5)
        self.assertEqual(tf.center("ciao"), self.centered)
        self.assertEqual(tf.spread("ciao","ciao"), self.spreaded)
        self.assert


if __name__ == "__main__":
    unittest.main()