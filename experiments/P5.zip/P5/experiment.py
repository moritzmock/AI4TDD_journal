import unittest

class TextFormatter():
  def setlinewidth(self, width):
    self.linewidth = width

  def centerWord(self, targetWord):
    remaining_spaces = self.linewidth - len(targetWord.strip())
    pre_spaces = remaining_spaces // 2
    post_spaces = remaining_spaces - pre_spaces 
    return ' ' * pre_spaces + targetWord.strip() + ' ' * post_spaces


  def spreadWords(self, targetWord1, targetWord2):
    remaining_spaces = self.linewidth - (len(targetWord1) + len(targetWord2))
    return targetWord1 + ' ' * remaining_spaces + targetWord2
  

formatter = TextFormatter()
class ExampleTestCase(unittest.TestCase):
    def test_example_1(self):
        formatter.setlinewidth(20)
        self.assertEqual(formatter.linewidth, 20)

    def test_example_2(self):
        formatter.setlinewidth(10)
        self.assertEqual(formatter.centerWord("hi"), "    hi    ")


    def test_example_3(self):
        formatter.setlinewidth(12)
        self.assertEqual(formatter.spreadWords("hello", "world"), "hello  world")


if __name__ == "__main__":
    unittest.main()