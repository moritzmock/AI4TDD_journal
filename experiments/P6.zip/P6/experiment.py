import unittest

class TextFormatter():
  def setLineWidth(self, width):
    self.width = width

  def getSetLineWidth(self):
    return self.width

  def setCenterWord(self, word, length):

    str_len = length - len(word)


    string = ""
    for i in range(0, str_len//2):
      string += " "

    string += word

    for i in range(0, str_len//2):
      string += " "

    return string

  def setCenterWords(self, word1, word2, length):

    str_len = length - len(word1) - len(word2)


    string = word1
    for i in range(0, str_len):
      string += " "

    string += word2

    return string


t = TextFormatter()

class ExampleTestCase(unittest.TestCase):

    def test_setLineWidth(self):
        t.setLineWidth(10)
        self.assertEqual(t.getSetLineWidth(), 10)

    def test_setCenterWord(self):
      t.setCenterWord("ciao", 20)
      self.assertEqual(t.setCenterWord("ciao", 20), "        ciao        ")

    def test_setCenterWords(self):
      t.setCenterWords("ciao", "Moritz", 20)
      self.assertEqual(t.setCenterWords("ciao", "Moritz", 20), "ciao          Moritz")


if __name__ == "__main__":
    unittest.main()