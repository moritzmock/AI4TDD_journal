import re
import unittest

class TextFormatter():
  def __init__(self) -> None:
    self.line_width = 0
  
  def set_line_width(self, width) -> None:
    self.line_width = width

  def get_word_in_center(self, word) -> str:
    spaces = ''.join(['\n' for i in range(self.line_width)])
    return spaces + word + spaces

  def space_center(self, word1, word2):
    return word1 + ''.join('\n' for i in range(self.line_width)) +word2

class ExampleTestCase(unittest.TestCase):
  def test_set_line_with(self):
    class_to_call = TextFormatter()
    class_to_call.set_line_width(10)
    self.assertEqual(class_to_call.line_width, 10)

  def test_get_word_in_center(self):
    class_to_call = TextFormatter()
    class_to_call.set_line_width(2)
    word = "hello"
    expected_value = f"\n\n{word}\n\n"
    self.assertEqual(class_to_call.get_word_in_center(word), expected_value)

  def test_space_center(self):
    class_to_call = TextFormatter()
    class_to_call.set_line_width(3)
    word1 = "a_platypus?"
    word2 = "oh_no_perry_the_platypus"
    expected_result = f"{word1}\n\n\n{word2}"
    self.assertEqual(class_to_call.space_center(word1, word2), expected_result)

if __name__ == "__main__":
    unittest.main()