import unittest

class TextFormatter():
  
  def setLineWidth(self, width):
    self.width = width
  
  def getLineWidth(self):
    return self.width

  def centerWord(self, word):
    gapLength = (self.width - len(word)) // 2
    gap = ' ' * gapLength
    return gap + word + gap

  def spreadWord(self, word1, word2):
    spreadLength = self.width - len(word1) - len(word2)
    spread = ' ' * spreadLength
    return word1 + spread + word2



class ExampleTestCase(unittest.TestCase):

  def testSetLineWidth(self):
    t = TextFormatter()
    t.setLineWidth(20)
    self.assertEqual(t.getLineWidth(), 20)

  def testCenterWord(self):
    t = TextFormatter()
    t.setLineWidth(20)
    result = t.centerWord('Ciao');
    self.assertEqual(result, '        Ciao        ')

  def testSpreadWords(self):
    t = TextFormatter()
    t.setLineWidth(20)
    result = t.spreadWord('Ciao', 'Franco');
    self.assertEqual(result, 'Ciao          Franco')



if __name__ == "__main__":
  unittest.main()
