import unittest

class IllegalArgumentError(ValueError):
    pass


class TextFormatter():
    def setLineWidth(self, lineWidth: int):
        if type(lineWidth) != int:
            raise TypeError(f"lineWidth {lineWidth} of type {type(lineWidth)} is not a valid argument.")

        if lineWidth <= 0:
            raise IllegalArgumentError(lineWidth)

        self.lineWidth = lineWidth

    def centerWord(self, word: str):
        if len(word) > self.lineWidth:
            raise IllegalArgumentError('Word {word} is to long. {len(word)} > {self.lineWidth}')

        right_spaces = int( (self.lineWidth - len(word)) / 2 )
        left_spaces = self.lineWidth - len(word) - right_spaces

        return  " " * left_spaces + word + " " * right_spaces

    def spreadWords(self, word1: str, word2: str):
        spaces = int( (self.lineWidth - len(word1) - len(word2)) / 2 )
        return " " * spaces + word1 + " " * spaces + word2 + " " * spaces


class ExampleTestCase(unittest.TestCase):
    def test_set_line_width(self):
        formatter = TextFormatter()
        formatter.setLineWidth(5)

        self.assertEqual(formatter.lineWidth, 5)

    def test_not_set_negative_line_width(self):
        formatter = TextFormatter()
        with self.assertRaises(IllegalArgumentError):
            formatter.setLineWidth(-5),

    def test_not_set_zero_line_width(self):
        formatter = TextFormatter()
        with self.assertRaises(IllegalArgumentError):
            formatter.setLineWidth(0),

    def test_not_set_non_int(self):
        formatter = TextFormatter()
        with self.assertRaises(TypeError):
            formatter.setLineWidth("foo")
        
    def test_not_set_float(self):
        formatter = TextFormatter()
        with self.assertRaises(TypeError):
            formatter.setLineWidth(1.1)

    def test_center_word_noop(self):
        formatter = TextFormatter()
        formatter.setLineWidth(5)
        output = formatter.centerWord("pippo")

        self.assertEqual("pippo", output)

    def test_center_word_even_remainder(self):
        formatter = TextFormatter()
        formatter.setLineWidth(5)
        output = formatter.centerWord("foo")

        self.assertEqual(" foo ", output)
        self.assertEqual(5, len(output))
    
    def test_center_word_uneven_remainder(self):
        formatter = TextFormatter()
        formatter.setLineWidth(5)
        output = formatter.centerWord("fo")

        self.assertEqual("  fo ", output)
        self.assertEqual(5, len(output))

    def test_raise_value_error_on_to_long_word(self):
        formatter = TextFormatter()
        formatter.setLineWidth(1)

        with self.assertRaises(IllegalArgumentError):
            formatter.centerWord("fooo")

    def test_raise_type_error_on_invalid_argument(self):
        formatter = TextFormatter()
        formatter.setLineWidth(5)

        with self.assertRaises(TypeError):
            formatter.centerWord(5)

    def test_spread_words_evenly(self):
        formatter = TextFormatter()
        formatter.setLineWidth(5)
        output = formatter.spreadWords("a", "b")

        self.assertEqual(" a b ", output)
        self.assertEqual(5, len(output))


if __name__ == "__main__":
    unittest.main()